import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import "bootstrap/dist/css/bootstrap.min.css"; 
import "bootstrap/dist/js/bootstrap.bundle.min";
import { BrowserRouter, Route, Routes } from 'react-router-dom';
// import Apiex from './axxxios/Apiex';
// import InsertRecord from './axxxios/InsertRecord';
// import Viewrecord from './axxxios/Viewrecord';
// import Editrecord from './axxxios/Editrecord'
import AddCourse from "./courseR/AddCourse";
import CourseList from "./courseR/CourseList";
import EditCourse from "./courseR/EditCourse";


//import SampleJSONaxios from './axxxios/SampleJSONaxios';
//import OnlineJsonAxios from './axxxios/OnlineJsonAxios';
//import UserDashboard from './User/UserDashboard';
//import Home from './User/Home';

// import Admin from './Admin/Admin';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    {/* <Admin /> */}
    {/* <UserDashboard/> */}
    {/* <SampleJSONaxios/> */}
    {/* <OnlineJsonAxios/> */}
    {/* <AddCourse/>
    <CourseList/>
    <EditCourse/> */}
   
   {/* <Apiex/> */}
   <Routes>
   {/* <Route exact path='/insert' element={<InsertRecord/>} />
   <Route exact path='/' element={<Viewrecord/>} />
   <Route exact path='/view' element={<Viewrecord/>} />
   <Route path="/edit/:empId" element={<Editrecord />} />  */}
         <Route path="/" element={<CourseList />} />
      <Route path="/add" element={<AddCourse />} />
      <Route path="/edit/:id" element={<EditCourse />} />
    </Routes>
  </BrowserRouter>
);


// import TestPage from './TestPage';
// import Calc from './Calc';

//  import RadioSample from './RadioSample';
//  import RadioSample2 from './RadioSample2';
//  import Bill from './Bill';
// import NavBar from './NavBar';
//  import Hotel from './Hotel';
//  import Registration from './Registration';
//  import Student from './Student';
//  import CheckBoxSample1 from './CheckBoxSample1';
//  import CheckBox_Fruits from './CheckBox_Fruits';



//  <React.StrictMode> 
//  //    <TestPage/>
// //  <Calc/>
// // <RadioSample/>
// // <RadioSample2/>
// // <Bill/> 
// // <NavBar/> 
// // <CheckBoxSample1/> 
// //  <CheckBox_Fruits/> 
// //  <Hotel/>
// // <Registration/>
// // <Student/>  

// // </React.StrictMode>



// ------------------------------------------------------------------------------------

// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import './index.css';
//import Login from './Login';
//import App from './App';
// import reportWebVitals from './reportWebVitals';
// import { BrowserRouter, Router, Routes, Route} from 'react-router-dom';
//import Home  from './Home';
//import About from './About';
//import Contact from './Contact';
//import ProductGallery from './ProductGallery';
//import ViewCart from './ViewCart';
// import Navbar from './components/Navbar';
// import Sidebar from './components/Sidebar';
// import Dashboard from './Admin/Dashboard';
// import User from './Admin/User';
// import Report from './Admin/Report';
// import Setting from './Admin/Setting';
// import NotFound from './Admin/NotFound';
// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
     
//       <Router>
//       <div>
//         <Navbar />
//         <div className="d-flex">
//           <Sidebar />
//           <main className="p-4" style={{ marginLeft: '200px', width: '100%' }}>
//       <Routes>
    //            <Route exact path="/" element={<Login/>} /> 
    //           <Route exact path="/Home" element={<Home/>} /> 
    //           <Route exact path="/About" element={<About/>} /> 
    //           <Route exact path="/Contact" element={<Contact/>} />
    //           <Route exact path="/ProductGallery" element={<ProductGallery/>} /> 
    //           <Route exact path="/ViewCart" element={<ViewCart />} /> 

    //  ~ADMIN 
              // <Route exact path="/" element={<Dashboard/>} /> 
              // <Route exact path="/User" element={<User/>} /> 
              // <Route exact path="/Report" element={<Report/>} /> 
              // <Route exact path="/Setting" element={<Setting/>} />
              // <Route exact path="/NotFound" element={<NotFound/>} />


   
//       </Routes>
//       </main>
//         </div>
//       </div>
//     </Router>

           
           
      
//   </React.StrictMode>
// );

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();
