import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = () => {
    axios.get('http://localhost:8000/courses')
      .then(res => {
        setCourses(res.data);
        setFilteredCourses(res.data); // also set filteredCourses initially
      })
      .catch(err => console.error('Failed to fetch courses', err));
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this course?")) {
      axios.delete(`http://localhost:8000/courses/${id}`)
        .then(() => {
          setMessage('Course deleted successfully.');
          const updated = courses.filter(course => course.course_id !== id);
          setCourses(updated);
          setFilteredCourses(updated);
        })
        .catch(err => {
          setMessage('Failed to delete course.');
          console.error(err);
        });
    }
  };

  const handleSearch = (e) => {
  const value = e.target.value.toLowerCase();
  setSearch(value);
  const filtered = courses.filter(course =>
    course.course_name.toLowerCase().includes(value)
  );
  setFilteredCourses(filtered);
};

  return (
    <div className="container mt-4">
      <h2>Courses</h2>

      {message && <div className="alert alert-info">{message}</div>}

      <div className="d-flex justify-content-between mb-3">
        <Link to="/add" className="btn btn-success">Add Course</Link>
        <input
          type="text"
          className="form-control w-50"
          placeholder="Search by name or department"
          value={search}
          onChange={handleSearch}
        />
      </div>

      {filteredCourses.length === 0 ? (
        <p>No courses found.</p>
      ) : (
        <table className="table table-bordered">
          <thead className="table-light">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Credits</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredCourses.map(c => (
              <tr key={c.course_id}>
                <td>{c.course_id}</td>
                <td>{c.course_name}</td>
                <td>{c.credits}</td>
                <td>{c.department}</td>
                <td>
                  <Link to={`/edit/${c.course_id}`} className="btn btn-primary btn-sm me-2">Edit</Link>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(c.course_id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default CourseList;
