import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './navbar.css';

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate('');
  };

  return (
    <nav className="navbar navbar-dark bg-dark px-4">
      
      <Link to="" className="navbar-brand text-light" style={{ textDecoration: 'none' }}>
        Admin Panel
      </Link>

      
      <button className="btn btn-outline-light" onClick={handleLogout}>
        Logout
      </button>
    </nav>
  );
};

export default Navbar;
