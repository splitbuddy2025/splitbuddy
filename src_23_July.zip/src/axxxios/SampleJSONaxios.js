import React, { useEffect } from 'react';
import axios from 'axios';
import { useState } from "react";

const SampleJSONaxios = () => {
const [result, setResult] = useState([]);
  
 function getData()
 {
  var url="test.http://localhost:8000/employee"
  axios.get(url)
  .then(response => {
   // alert(JSON.stringify(response.data));
    const record = response.data;
    setResult(response.data)
     console.log(record);
  })
}
  useEffect(() => {
   getData()
  }, 
);
  return (
    <center>
      <div className='col-sm-6'>
        <br/>
        <br/>
        <br/>
        
        <table class="table table-striped" border="1">
                          <thead>
                            <tr>
                              <th>Emp.no</th>
                              <th>Ename</th>
                              <th>Salary</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.map((data) =>
                              <tr>
                                <td>{data.Emp.no}</td>
                                <td>{data.Ename}</td>
                                <td> {data.Salary}</td>
                               </tr>
                            )}
                          </tbody>
                        </table>
                       
      </div>
      </center>
    )
  }
export default SampleJSONaxios;