import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OnlineJsonAxios = () => {
  const [result, setResult] = useState([]);

  const getData = () => {
    const url = "https://jsonplaceholder.typicode.com/posts";
    axios.get(url)
      .then(response => {
        setResult(response.data);
        console.log(response.data);
      });
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <center>
      <div className='col-sm-10'>
        
        <table className="table table-bordered table-striped" border="1">
          <thead className="table-dark">
            <tr>
              <th>User ID</th>
              <th>ID</th>
              <th>Title</th>
              <th>Body</th>
            </tr>
          </thead>
          <tbody>
            {result.map((data) => (
              <tr key={data.id}>
                <td>{data.userId}</td>
                <td>{data.id}</td>
                <td>{data.title}</td>
                <td>{data.body}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </center>
  );
};

export default OnlineJsonAxios;
