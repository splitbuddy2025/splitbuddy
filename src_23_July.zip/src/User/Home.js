import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import './navbar.css'; // Custom CSS file for styles

export default function Home() {
    const location = useLocation();

    return (
        <div className="home-page">
            {/* Gradient Background */}
            <div className="background">
                {/* Glassmorphic Navbar */}
                <div className="glass-navbar">
                    <ul className="nav-links">
                        <li><Link to="/UserHome/" className="nav-item">HOME</Link></li>
                        <li><Link to="/About" className="nav-item">ABOUT</Link></li>
                       
                        <li><Link to="/Contact" className="nav-item">CONTACT</Link></li>
                        <li><Link to="/ProductGallery" className="nav-item">PRODUCTGALLERY</Link></li>
                    </ul>
                </div>

                {/* Welcome Section */}
                <div className="welcome-section">
                    <h1>Welcome...</h1>
                    <div><b>{location.state?.user}</b></div>
                </div>
            </div>
        </div>
    );
}
