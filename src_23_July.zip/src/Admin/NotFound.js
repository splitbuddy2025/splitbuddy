import React from 'react';

const Setting = () => {
    return (
        <div>
            <h1>404 Page....</h1>
          <h1>NOT FOUND</h1>  
        </div>
    );
};

export default Setting;
