import React from 'react';

const User = () => {
    return (
        <div>
            <h1>User Page....</h1>
          <h1>USER</h1>  
        </div>
    );
};

export default User;
