import React from 'react';

const Setting = () => {
    return (
        <div>
            <h1>Setting Page....</h1>
          <h1>SETTING</h1>  
        </div>
    );
};

export default Setting;
