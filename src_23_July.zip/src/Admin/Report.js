import React from 'react';

const Report = () => {
    return (
        <div>
            <h1>Report Page....</h1>
          <h1>REPORT</h1>  
        </div>
    );
};

export default Report;
