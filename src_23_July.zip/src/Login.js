import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
    const navigate = useNavigate();
    const [data, setData] = useState({
        uname: "",
        pwd: "",
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setData((values) => ({
            ...values,
            [name]: value
        }));
    };

    const check = () => {
        const { uname, pwd } = data;
        if (uname === "Neel" && pwd === "123") {
            navigate("Home/", { state: { user: uname } });
        } else {
            alert("Sorry, incorrect username or password.");
        }
    };

    return (
        <div className="background">
            <div className="glass-navbar" style={{ width: '350px', padding: '30px' }}>
                <form>
                    <h3 style={{ color: '#2c3e50' }}>Login</h3>

                    <label htmlFor="uname" className="form-label">Username:</label>
                    <input
                        type="text"
                        id="uname"
                        name="uname"
                        placeholder="Enter Username"
                        value={data.uname}
                        onChange={handleChange}
                        className="form-control"
                    />

                    <label htmlFor="pwd" className="form-label mt-3">Password:</label>
                    <input
                        type="password"
                        id="pwd"
                        name="pwd"
                        placeholder="Enter Password"
                        value={data.pwd}
                        onChange={handleChange}
                        className="form-control"
                    />

                    <button
                        type="button"
                        className="btn btn-primary mt-4"
                        onClick={check}
                        style={{ width: '100%' }}
                    >
                        Submit
                    </button>
                </form>
            </div>
        </div>
    );
}
