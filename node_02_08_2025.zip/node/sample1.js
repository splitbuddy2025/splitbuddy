var http = require('http');
var ser=http.createServer(
    function (req,res) {
        res.writeHead(200, {'content-type': 'text/html'});
        res.end('<b> Learning NodeMon First Code</b>');

    }
);
ser.listen(3000);
console.log("Server is Working..........");