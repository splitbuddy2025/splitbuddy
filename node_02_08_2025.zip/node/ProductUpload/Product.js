const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'employee'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '_' + file.originalname);
  }
});
const upload = multer({ storage: storage });

app.post('/product', upload.single('pro_image'), (req, res) => {
  const { pro_name, pro_price } = req.body;
  const pro_image = req.file ? `/uploads/${req.file.filename}` : null;

  db.query(
    'INSERT INTO product (pro_name, pro_price, pro_image) VALUES (?, ?, ?)',
    [pro_name, pro_price, pro_image],
    (err, result) => {
      if (err) return res.status(500).send(err);
      res.send({ message: 'Product added', id: result.insertId });
    }
  );
});

app.get('/product', (req, res) => {
  db.query('SELECT * FROM product', (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

app.get('/product/:id', (req, res) => {
  db.query(
    'SELECT * FROM product WHERE pro_id = ?',
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).send(err);
      if (result.length === 0) return res.status(404).send({ message: 'Not found' });
      res.send(result[0]);
    }
  );
});

app.put('/product/:id', upload.single('pro_image'), (req, res) => {
  const { pro_name, pro_price } = req.body;
  const pro_image = req.file ? `/uploads/${req.file.filename}` : null;

  let query = 'UPDATE product SET pro_name = ?, pro_price = ?';
  let values = [pro_name, pro_price];

  if (pro_image) {
    query += ', pro_image = ?';
    values.push(pro_image);
  }

  query += ' WHERE pro_id = ?';
  values.push(req.params.id);

  db.query(query, values, (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ message: 'Product updated' });
  });
});

app.delete('/product/:id', (req, res) => {
  db.query('DELETE FROM product WHERE pro_id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ message: 'Product deleted' });
  });
});

app.listen(8000, () => console.log('Server running on port 8000'));
