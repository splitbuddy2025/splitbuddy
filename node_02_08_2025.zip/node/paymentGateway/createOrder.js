const express = require("express");
const Razorpay = require("razorpay");
const cors = require("cors");

const app = express();
const PORT = 5000; // or any other port you prefer

// Middleware
app.use(cors());
app.use(express.json());

// Razorpay instance

const instance = new Razorpay({
  key_id: "rzp_test_ughhWElb2p782f",
  key_secret: "tNChwsqQaP2kplzdKDN4IlEs",
});

// Routes
app.post("/create-order", async (req, res) => {
  const { amount } = req.body;

  const options = {
    amount: amount * 100, // convert to paise
    currency: "INR",
    receipt: "receipt_order_" + Math.random().toString(36).substring(7),
  };

  try {
    const order = await instance.orders.create(options);
    res.status(200).json(order);
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).send("Error creating order");
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
