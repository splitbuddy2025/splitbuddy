var { check, validationResult } = require('express-validator'); 
var bodyparser = require('body-parser') ;
var express = require("express") ;
var app = express() ;

app.use(bodyparser.urlencoded({ extended: false })) 


app.get("/empvalidationform", function (req, res) { 
    res.sendFile(__dirname+"/empvalidationform.html"); 
}) 

app.post('/submitData', 
    [  
   check('empId', 'Employee ID is required').isNumeric(),

    check('empName', 'Name must be between 5 and 20 characters')
      .isLength({ min: 5, max: 20 }),

    check('gender', 'Gender is required'),

    check('city', 'City must be selected'),

    check('skills', 'At least one skill must be selected'),

    check('address', 'Address must be at least 10 to 50 characters')
      .isLength({ min: 10, max:50 }),
    ], 
(req, res) => { 

    var errors = validationResult(req); 


    if (!errors.isEmpty()) { 
        res.json(errors) 
    } 
   
    else { 
    var empId=req.body.empId;
    var empName=req.body.empName;
    var gender=req.body.gender;
    var city=req.body.city;
    var skills=req.body.skills;
    var address=req.body.address;
    res.send( "Successfully form submitted...." + empId+ "<br> "+ empName+"<br>"+ gender+"<br>"+ city+"<br>"+skills+"<br>"+address+"<br>" );
    } 
}); 



var server = app.listen(2705, function () {
    console.log('2705  server is running..');
});