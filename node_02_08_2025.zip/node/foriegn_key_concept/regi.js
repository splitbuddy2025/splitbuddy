// Regi.js
const express = require("express");
const bodyParser = require("body-parser");
const connection = require("./db"); // make sure this path is correct
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

// 🔧 Optional: Add GET route for testing
app.get("/", (req, res) => {
  res.send("API is running...");
});

// ✅ POST /registration
app.post("/registration", (req, res) => {
  const { name, email, password } = req.body;

  const query =
    "INSERT INTO registration (rname, remail, rpassword) VALUES (?, ?, ?)";

  connection.query(query, [name, email, password], (err, results) => {
    if (err) {
      console.error("Error inserting student:", err);
      res.status(500).send("Server error");
    } else {
      res.status(201).send("Registration successful");
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
