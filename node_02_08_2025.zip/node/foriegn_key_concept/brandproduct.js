const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const app = express();
const session = require('express-session');
const PORT = 4000;

app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
app.use(express.json());
app.use(session({
  secret: 'admin', 
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, 
    httpOnly: true,
    maxAge: 1000 * 60 * 60 
  }
}));
app.use('/upload', express.static('upload'));


// Multer setup for image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'upload/'),
  filename: (req, file, cb) => {
    cb(null, file.originalname); // will rename later
  }
});
const upload = multer({ storage });


app.post('/login', (req, res) => {
  const { remail, rpassword } = req.body;
  db.query(
    'SELECT * FROM registration WHERE remail = ? AND rpassword = ?',
    [remail, rpassword],
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Server error' });
      if (results.length === 0) return res.status(401).json({ message: 'Invalid credentials' });

      req.session.user = results[0]; // ✅ Save user in session
      res.json({ message: 'Login successful', user: results[0] });
    }
  );
});

app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to destroy session' });
    }
    res.clearCookie('connect.sid'); // Optional: clear session cookie
    res.json({ message: 'Logged out successfully' });
  });
});


app.post("/registration", (req, res) => {
  const { name, email, password } = req.body;

  const query =
    "INSERT INTO registration (rname, remail, rpassword) VALUES (?, ?, ?)";

  db.query(query, [name, email, password], (err, results) => {
    if (err) {
      console.error("Error inserting student:", err);
      res.status(500).send("Server error");
    } else {
      res.status(201).send("Registration successful");
    }
  });
});

/* ----------------------- BRAND ROUTES ----------------------- */

app.post('/brand/insert', upload.single('b_logo'), (req, res) => {
  const { b_name } = req.body;
  const b_logo = req.file ? req.file.filename : null;

  const sql = 'INSERT INTO product_brand (b_name, b_logo) VALUES (?, ?)';
  db.query(sql, [b_name, b_logo], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Brand added', id: result.insertId });
  });
});

app.get('/brand/view', (req, res) => {
  
  if (!req.session.user) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  db.query('SELECT * FROM product_brand', (err, results) => {
    if (err) return res.status(500).json({ message: 'Server error' });
    res.json(results);
  });
});

app.get('/brand/:id', (req, res) => {
    const { id } = req.params;
  
    const sql = 'SELECT * FROM product_brand WHERE b_id = ?';
    db.query(sql, [id], (err, result) => {
      if (err) return res.status(500).json(err);
  
      if (result.length === 0) {
        return res.status(404).json({ message: 'Brand not found' });
      }
  
      res.json(result[0]);
    });
  });
  
app.put('/brand/update/:id', upload.single('b_logo'), (req, res) => {
    const { b_name } = req.body;
    const { id } = req.params;
    let sql, values;
  
    if (req.file) {
      const b_logo = req.file.filename;
      sql = 'UPDATE product_brand SET b_name = ?, b_logo = ? WHERE b_id = ?';
      values = [b_name, b_logo, id];
    } else {
      sql = 'UPDATE product_brand SET b_name = ? WHERE b_id = ?';
      values = [b_name, id];
    }
  
    db.query(sql, values, (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Brand updated successfully' });
    });
  });

app.delete('/brand/delete/:id', (req, res) => {
    const { id } = req.params;
  
    // First, fetch the logo filename to delete the image file if needed
    const fetchSql = 'SELECT b_logo FROM product_brand WHERE b_id = ?';
    db.query(fetchSql, [id], (err, result) => {
      if (err) return res.status(500).json(err);
  
      const logoFilename = result[0]?.b_logo;
      if (logoFilename) {
        const filePath = path.join(__dirname, 'upload', logoFilename);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath); // Delete logo file from upload folder
        }
      }
  
      // Now delete brand from database
      const deleteSql = 'DELETE FROM product_brand WHERE b_id = ?';
      db.query(deleteSql, [id], (err2) => {
        if (err2) return res.status(500).json(err2);
        res.json({ message: 'Brand deleted successfully' });
      });
    });
  });
  

/* ----------------------- MOBILE ROUTES ----------------------- */

// Insert Mobile Product with multiple images
app.post('/mobile/insert', upload.array('images', 5), (req, res) => {
  const { model_no, price, b_id, features } = req.body;

  if (!model_no || !price || !b_id || !features || !req.files.length) {
    return res.status(400).json({ error: 'All fields and at least one image are required.' });
  }

  const renamedImages = req.files.map((file, index) => {
    const ext = path.extname(file.originalname);
    const safeModelNo = model_no.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_-]/g, '');
    const newFilename = `${safeModelNo}_${index + 1}${ext}`;
    const newPath = path.join(file.destination, newFilename);
    fs.renameSync(file.path, newPath);
    return newFilename;
  });

  const imageString = renamedImages.join(',');

  const sql = 'INSERT INTO products (model_no, price, image, b_id, features) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [model_no, price, imageString, b_id, features], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Mobile added', id: result.insertId });
  });
});

// View all mobiles with brand name
app.get('/mobile/view', (req, res) => {
    const sql = `
      SELECT p.*, b.b_name AS brand_name
      FROM products p
      JOIN product_brand b ON p.b_id = b.b_id
      ORDER BY p.m_id ASC
    `;
    db.query(sql, (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
    });
  });  
  app.get('/mobile/update/:id', (req, res) => {
    const { id } = req.params;
  
    const sql = 'SELECT * FROM products WHERE m_id = ?';
    db.query(sql, [id], (err, result) => {
      if (err) return res.status(500).json(err);
  
      if (result.length === 0) {
        return res.status(404).json({ message: 'Product not found' });
      }
  
      res.json(result[0]);
    });
});
  
app.put('/mobile/update/:id', upload.array('images', 5), (req, res) => {
  const { model_no, price, features, b_id } = req.body;
  const { id } = req.params;

  // If new images are uploaded
  if (req.files && req.files.length > 0) {
    // Step 1: Get current image filenames from DB
    db.query('SELECT image FROM products WHERE m_id = ?', [id], (err, result) => {
      if (err) return res.status(500).json(err);
      if (result.length === 0) return res.status(404).json({ message: 'Mobile not found' });

      const oldImages = result[0].image?.split(',') || [];

      // Step 2: Delete old images from disk
      oldImages.forEach(img => {
        const filePath = path.join(__dirname, 'upload', img);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      });

      // Step 3: Rename and save new images
      const renamedImages = req.files.map((file, index) => {
        const ext = path.extname(file.originalname);
        const safeModelNo = model_no.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_-]/g, '');
        const newFilename = `${safeModelNo}_${index + 1}${ext}`;
        const newPath = path.join(file.destination, newFilename);
        fs.renameSync(file.path, newPath);
        return newFilename;
      });

      const imageString = renamedImages.join(',');

      // Step 4: Update DB
      const sql = 'UPDATE products SET model_no = ?, price = ?, image = ?, b_id = ?, features = ? WHERE m_id = ?';
      const values = [model_no, price, imageString, b_id, features, id];
      db.query(sql, values, (err2, result2) => {
        if (err2) return res.status(500).json(err2);
        res.json({ message: 'Mobile updated with new images' });
      });
    });

  } else {
    // No new images uploaded: update other fields only
    const sql = 'UPDATE products SET model_no = ?, price = ?, b_id = ?, features = ? WHERE m_id = ?';
    const values = [model_no, price, b_id, features, id];
    db.query(sql, values, (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Mobile updated without changing images' });
    });
  }
});

// Delete mobile
app.delete('/mobile/:id', (req, res) => {
  db.query('DELETE FROM products WHERE m_id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Mobile deleted' });
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});