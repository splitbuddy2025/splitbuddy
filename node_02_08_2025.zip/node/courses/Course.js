const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'employee' 
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

// Routes
app.post('/courses', (req, res) => {
  const { course_name, credits, department } = req.body;
  db.query(
    'INSERT INTO course (course_name, credits, department) VALUES (?, ?, ?)',
    [course_name, credits, department],
    (err, result) => {
      if (err) return res.status(500).send(err);
      res.send({ message: 'Course added', id: result.insertId });
    }
  );
});

app.get('/courses', (req, res) => {
  db.query('SELECT * FROM course', (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

app.get('/courses/:id', (req, res) => {
  db.query(
    'SELECT * FROM course WHERE course_id = ?',
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).send(err);
      if (result.length === 0) return res.status(404).send({ message: 'Not found' });
      res.send(result[0]);
    }
  );
});

app.put('/courses/:id', (req, res) => {
  const { course_name, credits, department } = req.body;
  db.query(
    'UPDATE course SET course_name = ?, credits = ?, department = ? WHERE course_id = ?',
    [course_name, credits, department, req.params.id],
    (err, result) => {
      if (err) return res.status(500).send(err);
      res.send({ message: 'Course updated' });
    }
  );
});

app.delete('/courses/:id', (req, res) => {
  db.query(
    'DELETE FROM course WHERE course_id = ?',
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).send(err);
      res.send({ message: 'Course deleted' });
    }
  );
});

app.listen(8000, () => console.log('Server running on port 8000'));
