import React from 'react';

const RadioSample2 = () => {
  const [choice, setChoice] = React.useState('');
  const [num, setNum] = React.useState('');
  const [res, setResult] = React.useState('');
  
  const handleChange = (event) => {
    setChoice(event.target.value)
    if (event.target.value==='S')
        setResult(num*num);
    else if (event.target.value==='C')
        setResult(num*num*num);
    else if (event.target.value==='R')
        setResult(Math.sqrt(num));
  }
  
  const handleChange2 = (event) => {
    setNum(event.target.value)
  }
  return (
    <form>
      <label>No</label>
      <input type="text" value={num} onChange={handleChange2} />
      <p>Choice</p>
      <div>
        <input
          type="radio"
          value="S"
          checked={choice === 'S'}
          onChange={handleChange}
        /> Square
      </div>
      <div>
        <input
          type="radio"
          value="C"
          checked={choice === 'C'}
          onChange={handleChange}
        /> Cube
      </div>
      <div>
        <input
          type="radio"
          value="R"
          checked={choice === 'R' }
          onChange={handleChange}
        /> Square Root
      </div>
      <label>Result</label>
      <input type="text" value={res} />
      
    </form>
  )
}
export default RadioSample2;