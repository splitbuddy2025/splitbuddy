import React, { useState } from 'react';

function Calc() {
  const [No1, setNo1] = useState('0');
  const [No2, setNo2] = useState('0');
  const [Result, setResult] = useState('0');

  const [length, setLength] = useState('0');
  const [width, setWidth] = useState('0');
  const [height, setHeight] = useState('0');
  const [volume, setVolume] = useState('0');

  const [lengthA, setLengthA] = useState('0');
  const [widthA, setWidthA] = useState('0');
  const [area, setArea] = useState('0');

  const handleAddition = () => {
    setResult(parseInt(No1) + parseInt(No2));
  };

  const calculateVolume = () => {
    setVolume(parseInt(length) * parseInt(width) * parseInt(height));
  };

  const calculateArea = () => {
    setArea(parseInt(lengthA) * parseInt(widthA));
  };

  return (
    <div>
      <h3>Calculate</h3>
      <form>
        No1:
        <input type="number" value={No1} onChange={e => setNo1(e.target.value)} /><br />
        No2:
        <input type="number" value={No2} onChange={e => setNo2(e.target.value)} /><br />
        Answer:
        <input type="text" value={Result} readOnly /><br />
        <input type="button" value="Add" onClick={handleAddition} />
      </form>

      <h3>Volume </h3>
      <form>
        Length:
        <input type="number" value={length} onChange={e => setLength(e.target.value)} /><br />
        Width:
        <input type="number" value={width} onChange={e => setWidth(e.target.value)} /><br />
        Height:
        <input type="number" value={height} onChange={e => setHeight(e.target.value)} /><br />
        Volume:
        <input type="text" value={volume} readOnly /><br />
        <input type="button" value="Calculate Volume" onClick={calculateVolume} />
      </form>

      <h3>Area </h3>
      <form>
        Length:
        <input type="number" value={lengthA} onChange={e => setLengthA(e.target.value)} /><br />
        Width:
        <input type="number" value={widthA} onChange={e => setWidthA(e.target.value)} /><br />
        Area:
        <input type="text" value={area} readOnly /><br />
        <input type="button" value="Calculate Area" onClick={calculateArea} />
      </form>
    </div>
  );
}

export default Calc;
