const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'employee'
});

connection.connect(err => {
  if (err) {
    console.error('Database connection failed:', err);
    process.exit();
  }
  console.log('✅ Connected to MySQL');
});

// CREATE
app.post('/employee', (req, res) => {
  const { Emp_no, Ename, Salary } = req.body;
  const sql = 'INSERT INTO emp (Emp_no, Ename, Salary) VALUES (?, ?, ?)';
  connection.query(sql, [Emp_no, Ename, Salary], (err, result) => {
    if (err) {
      console.error('❌ Insert error:', err);
      return res.status(500).send(err.sqlMessage);
    }
    res.send('Employee inserted successfully');
  });
});

// READ ALL
app.get('/employee', (req, res) => {
  connection.query('SELECT * FROM emp', (err, results) => {
    if (err) {
      console.error('❌ Fetch error:', err);
      return res.status(500).send(err.sqlMessage);
    }
    res.json(results);
  });
});

// ✅ READ ONE (for edit autofill)
app.get('/employee/:Emp_no', (req, res) => {
  const { Emp_no } = req.params;
  const sql = 'SELECT * FROM emp WHERE Emp_no = ?';
  connection.query(sql, [Emp_no], (err, results) => {
    if (err) {
      console.error('❌ Fetch single error:', err);
      return res.status(500).send(err.sqlMessage);
    }
    if (results.length === 0) {
      return res.status(404).send('Employee not found');
    }
    res.json(results[0]); // send single object, not array
  });
});

// UPDATE
app.put('/employee/:Emp_no', (req, res) => {
  const { Ename, Salary } = req.body;
  const { Emp_no } = req.params;
  const sql = 'UPDATE emp SET Ename = ?, Salary = ? WHERE Emp_no = ?';
  connection.query(sql, [Ename, Salary, Emp_no], (err, result) => {
    if (err) {
      console.error('❌ Update error:', err);
      return res.status(500).send(err.sqlMessage);
    }
    res.send('Employee updated successfully');
  });
});

// DELETE
app.delete('/employee/:Emp_no', (req, res) => {
  const { Emp_no } = req.params;
  const sql = 'DELETE FROM emp WHERE Emp_no = ?';
  connection.query(sql, [Emp_no], (err, result) => {
    if (err) {
      console.error('❌ Delete error:', err);
      return res.status(500).send(err.sqlMessage);
    }
    res.send('Employee deleted successfully');
  });
});

// Start server
const PORT = 8000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
