var http = require('http');
var ser=http.createServer(
    function (req,res) {
        if(req.url ==  '/'){
              res.writeHead(200, {'content-type': 'text/html'});
              res.write('<html><body>WELCOME HOME PAGE.......</body></html>')
              res.end();
        }
        else if (req.url =="/about"){
            res.writeHead(200,{'content-type': 'text/html'})
         
              res.write('<html><body>THIS IS ABOUT US PAGE...</body></html>')
              res.end();
        }
        else if (req.url =="/contact")
        {
            res.writeHead(200,{'content-type': 'text/html'})
          
              res.write('<html><body>THIS IS CONTACT PAGE...</body></html>')
              res.end();
        }
        else {
            res.writeHead(404,{'content-type': 'text/html'});
            res.end('<h1> NOT FOUND </h1>')
        }
    }
    );
    ser.listen(3000);
    console.log("Server is Working..........");