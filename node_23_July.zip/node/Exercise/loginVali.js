var { check, validationResult } = require('express-validator'); 
var bodyparser = require('body-parser') ;
var express = require("express") ;
var app = express() ;

app.use(bodyparser.urlencoded({ extended: false })) 


app.get("/loginvalidation", function (req, res) { 
    res.sendFile(__dirname+"/loginValidation.html"); 
}) 

app.post('/submitData', 
    [  
    check('name', 'Name length should be 10 to 20 characters') 
                    .isLength({ min: 10, max: 10 }), 
    check('password', 'Password length should be 8 to 10 characters') 
                    .isLength({ min: 8 }) 
    ], 
(req, res) => { 

    var errors = validationResult(req); 


    if (!errors.isEmpty()) { 
        res.json(errors) 
    } 
   
    else { 
        res.send("Successfully validated") 
    } 
}); 

var server = app.listen(2705, function () {
    console.log('2705  server is running..');
});