var http = require('http'); 

var server = http.createServer(function (req, res) {   
   
    if (req.url == '/data') { //check the URL of the current request
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.write(JSON.stringify({ message: "Hello World"}));  
            res.end();  
    }
    if (req.url == '/mynode') { //check the URL of the current request
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write("<b>Good Day</b>");
            res.write("<b>Every one</b>");
              
            res.end();  
    }
    
    if (req.url == '/') { //check the URL of the current request
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.write( "<b>Hello World</b>");  
            res.end();  
    }
});

server.listen(8080);

console.log('Node.js web server at port 8080 is running..')