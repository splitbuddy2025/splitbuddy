
var express = require('express');
var app = express();

var nmod = require('./exprouter.js');


app.use('/', nmod);

app.use('/test', nmod);


app.listen(8000);