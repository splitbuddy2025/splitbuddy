var { check, validationResult } = require('express-validator'); 
var bodyparser = require('body-parser') ;
var express = require("express") ;
var app = express() ;



// View Engine Setup 
// app.set("views", path.join(__dirname)) 
// app.set("view engine", "ejs") 
//var path = require('path')


// Body-parser middleware 
app.use(bodyparser.urlencoded({ extended: false })) 
//app.use(bodyparser.json()) 

app.get("/register", function (req, res) { 
	res.sendFile(__dirname+"/ValidationForm.html"); 
}) 

// check() is a middleware used to validate 
// the incomming data as per the fields 
app.post('/submitData', [ 
	check('email', 'Email length should be 10 to 30 characters') 
					.isEmail().isLength({ min: 10, max: 30 }), 
	check('name', 'Name length should be 10 to 20 characters') 
					.isLength({ min: 10, max: 20 }), 
	check('mobile', 'Mobile number should contains 10 digits') 
					.isLength({ min: 10, max: 10 }), 
	check('password', 'Password length should be 8 to 10 characters') 
					.isLength({ min: 8, max: 10 }) 
], (req, res) => { 
 
	//    check('age').isNumeric().withMessage('Age must be a number'),
      //  check('age').isInt({ min: 18, max: 60 }).withMessage('Age must be between 18 and 60')

	// validationResult function checks whether 
	// any occurs or not and return an object 
	var errors = validationResult(req); 


	// If some error occurs, then this 
	// block of code will run 
	if (!errors.isEmpty()) { 
		res.json(errors) 
	} 
	// If no error occurs, then this 
	// block of code will run 
	else { 
		res.send("Successfully validated") 
	} 
}); 

var server = app.listen(8000, function () {
    console.log('8000  server is running..');
});