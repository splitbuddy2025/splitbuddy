import React from "react";

const Bill = () => {
  const [choice, setChoice] = React.useState('');
  const [num, setNum] = React.useState('');
  const [res, setResult] = React.useState('');

  const rate = 100;

  const billAmount = (qty, option) => {
    const total = qty * rate;
    let finalAmount = 0;

    if (option === 'H') {
      finalAmount = total - total * 0.10;
    } else if (option === 'R') {
      finalAmount = total;
    } else if (option === 'F') {
      finalAmount = total + total * 0.20;
    }

    setResult(finalAmount.toFixed(2));
  };

  const handleChoiceChange = (event) => {
    const selected = event.target.value;
    setChoice(selected);
    if (num) {
      billAmount(num, selected);
    }
  };

  const handleQuantityChange = (event) => {
    const qty = Number(event.target.value);
    setNum(qty);
    if (choice) {
      billAmount(qty, choice);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Amount Calculator</h2>
      <form className="p-4 border rounded shadow-sm bg-light">
        <div className="mb-3">
          <label className="form-label">Your Name:</label>
          <input type="text" className="form-control" placeholder="Your Name" />
        </div>

        <div className="mb-3">
          <label className="form-label">Quantity:</label>
          <input
            type="number"
            className="form-control"
            value={num}
            onChange={handleQuantityChange}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Rate:</label>
          <input
            type="number"
            className="form-control"
            value={rate}
            readOnly
          />
        </div>

        <div className="mb-3">
          <label className="form-label"><strong>Choice:</strong></label>
          <div className="form-check">
            <input
              type="radio"
              className="form-check-input"
              id="happy"
              value="H"
              name="option"
              checked={choice === 'H'}
              onChange={handleChoiceChange}
            />
            <label className="form-check-label" htmlFor="happy">
              Happy Hours (10% Discount)
            </label>
          </div>

          <div className="form-check">
            <input
              type="radio"
              className="form-check-input"
              id="regular"
              value="R"
              name="option"
              checked={choice === 'R'}
              onChange={handleChoiceChange}
            />
            <label className="form-check-label" htmlFor="regular">
              Regular (No Change)
            </label>
          </div>

          <div className="form-check">
            <input
              type="radio"
              className="form-check-input"
              id="funtime"
              value="F"
              name="option"
              checked={choice === 'F'}
              onChange={handleChoiceChange}
            />
            <label className="form-check-label" htmlFor="funtime">
              Funtime (20% Increase)
            </label>
          </div>
        </div>

        <div className="mb-3">
          <label className="form-label">Amount:</label>
          <input
            type="text"
            className="form-control"
            value={res}
            readOnly
          />
        </div>
      </form>
    </div>
  );
};

export default Bill;
