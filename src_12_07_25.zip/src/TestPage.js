import React,{useState} from 'react';

const TestPage
 = () => {
    const [user, setUser] = useState('Neel');
    const [pass, setPassword] = useState('');
    const handleChange = event =>setUser(event.target.value);
    const handleChange2 = event =>setPassword(event.target.value);
    const check=() =>
    {
        if (user==="Neel" && pass==="2705")
            alert ("Welcome ...."+ user);
        else 
            alert ("sorry...");
    }

    return (
        <div>
            <div>
            <form>
                
                username:
                <input type="text" name="user"  value={user} onChange={handleChange}/><br/>

                Password:
                 <input type="password" name="password"  value={pass} onChange={handleChange2}/><br/>

                    <input type="submit" value="Login" onClick={check}></input>
            </form>
        
  </div>
        </div>
    );
};

export default TestPage
;
