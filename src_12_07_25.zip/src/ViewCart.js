import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const ViewCart = () => {
  const location = useLocation();
  const cart = location.state?.cart || [];
  const navigate = useNavigate();

  return (
    <div className="background">
      <div className="glass-navbar" style={{ width: '80%', padding: '30px' }}>
        <h2 style={{ textAlign: 'center', color: '#2c3e50' }}>Cart Items</h2>

        {cart.length === 0 ? (
          <p style={{ textAlign: 'center', color: 'white' }}>Your cart is empty.</p>
        ) : (
          <table
            border="1"
            width="100%"
            cellPadding="10"
            style={{ backgroundColor: 'white', color: 'black', textAlign: 'center' }}
          >
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Price (Rs.)</th>
              </tr>
            </thead>
            <tbody>
              {cart.map((item, index) => (
                <tr key={index}>
                  <td>{item.name}</td>
                  <td>{item.price}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div style={{ textAlign: 'center', marginTop: '20px' }}>
          <button onClick={() => navigate('/ProductGallery')} style={{ marginRight: '10px' }}>
            Back to Product Gallery
          </button>
          <button onClick={() => navigate('/')}>
            Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default ViewCart;
