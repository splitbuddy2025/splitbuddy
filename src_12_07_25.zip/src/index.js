// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import './index.css';
 import "bootstrap/dist/css/bootstrap.min.css"; 
 import "bootstrap/dist/js/bootstrap.bundle.min";

// import reportWebVitals from './reportWebVitals';

// import TestPage from './TestPage';
// import Calc from './Calc';

//  import RadioSample from './RadioSample';
//  import RadioSample2 from './RadioSample2';
//  import Bill from './Bill';
// import NavBar from './NavBar';
//  import Hotel from './Hotel';
//  import Registration from './Registration';
//  import Student from './Student';
//  import CheckBoxSample1 from './CheckBoxSample1';
//  import CheckBox_Fruits from './CheckBox_Fruits';

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
//    <TestPage/>
//  <Calc/>
// <RadioSample/>
// <RadioSample2/>
// <Bill/> 
// <NavBar/> 
// <CheckBoxSample1/> 
//  <CheckBox_Fruits/> 
//  <Hotel/>
// <Registration/>
// <Student/> 

//   </React.StrictMode>
// );
// reportWebVitals();


// ------------------------------------------------------------------------------------

import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Login from './Login';
//import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, Route,Routes } from 'react-router-dom';
import Home  from './Home';
import About from './About';
import Contact from './Contact';
import ProductGallery from './ProductGallery';
import ViewCart from './ViewCart';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
     
      <BrowserRouter>
      <Routes>
             <Route exact path="/" element={<Login/>} /> 
           
             <Route exact path="/Home" element={<Home/>} /> 
             <Route exact path="/About" element={<About/>} /> 
           
             <Route exact path="/Contact" element={<Contact/>} />
          <Route exact path="/ProductGallery" element={<ProductGallery/>} /> 
            <Route exact path="/ViewCart" element={<ViewCart />} />
   
            </Routes>
      

           
           
      </BrowserRouter>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
