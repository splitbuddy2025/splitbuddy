import React from 'react';
import { Link } from 'react-router-dom';
import './sidebar.css';

const Sidebar = () => (
  <div className="sidebar bg-light">
    <ul className="nav flex-column p-3">
      {/* <li className="nav-item">
        <Link to="/dashboard" className="nav-link">Dashboard</Link>
      </li> */}
      <li className="nav-item">
        <Link to="/User" className="nav-link">Users</Link>
      </li>
      <li className="nav-item">
        <Link to="/Report" className="nav-link">Reports</Link>
      </li>
      <li className="nav-item">
        <Link to="/Setting" className="nav-link">Settings</Link>
      </li>
    </ul>
  </div>
);

export default Sidebar;
