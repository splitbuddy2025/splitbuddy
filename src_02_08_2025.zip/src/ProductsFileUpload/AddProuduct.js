import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AddProduct = () => {
  const [data, setData] = useState({
    pro_name: '',
    pro_price: '',
    pro_image: null
  });
  const [preview, setPreview] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setData(prev => ({ ...prev, pro_image: file }));
      setPreview(URL.createObjectURL(file));
      setError('');
    } else {
      setData(prev => ({ ...prev, pro_image: null }));
      setPreview('');
      setError('Please select a valid image file.');
    }
  };

  const validate = () => {
    if (!data.pro_name.trim()) {
      setError('Product name is required.');
      return false;
    }
    if (!/^[A-Za-z\s]{3,}$/.test(data.pro_name.trim())) {
      setError('Product name must be at least 3 characters and only letters/spaces.');
      return false;
    }
    if (!data.pro_price) {
      setError('Product price is required.');
      return false;
    }
    if (isNaN(data.pro_price) || Number(data.pro_price) <= 0) {
      setError('Product price must be a number greater than 0.');
      return false;
    }
    if (!data.pro_image) {
      setError('Product image is required.');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validate()) return;

    const formData = new FormData();
    formData.append('pro_name', data.pro_name.trim());
    formData.append('pro_price', data.pro_price);
    formData.append('pro_image', data.pro_image);

    try {
      await axios.post('http://localhost:8000/product', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setSuccess('Product added successfully!');
      setTimeout(() => navigate('/'), 1500);
    } catch (err) {
      setError('Failed to add product. Please try again.');
    }
  };

  return (
    <div className="container mt-4">
      <h2>Add Product</h2>

      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label className="form-label">Product Name</label>
          <input
            type="text"
            name="pro_name"
            className="form-control"
            value={data.pro_name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Product Price</label>
          <input
            type="number"
            name="pro_price"
            className="form-control"
            value={data.pro_price}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Product Image</label>
          <input
            type="file"
            name="pro_image"
            className="form-control"
            onChange={handleFileChange}
            accept="image/*"
            required
          />
          {preview && (
            <img
              src={preview}
              alt="Preview"
              style={{ marginTop: '10px', width: '120px', border: '1px solid #ccc' }}
            />
          )}
        </div>

        <button type="submit" className="btn btn-primary">Add Product</button>
      </form>
    </div>
  );
};

export default AddProduct;
