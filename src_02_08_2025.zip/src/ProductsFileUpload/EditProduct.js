import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const EditProduct = () => {
  const { id } = useParams();
  const [data, setData] = useState({
    pro_name: '',
    pro_price: '',
    pro_image: ''
  });
  const [imagePreview, setImagePreview] = useState('');
  const [newImage, setNewImage] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`http://localhost:8000/product/${id}`)
      .then(res => {
        setData(res.data);
        setImagePreview(`http://localhost:8000${res.data.pro_image}`);
        setLoading(false);
      })
      .catch(err => {
        setError('Failed to load product');
        setLoading(false);
        console.error(err);
      });
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setNewImage(file);
      setImagePreview(URL.createObjectURL(file));
      setError('');
    } else {
      setNewImage(null);
      setImagePreview('');
      setError('Please select a valid image file.');
    }
  };

  const validate = () => {
    if (!data.pro_name.trim()) {
      setError('Product name is required.');
      return false;
    }
    if (!/^[A-Za-z\s]{3,}$/.test(data.pro_name.trim())) {
      setError('Product name must be at least 3 characters and only letters/spaces.');
      return false;
    }
    if (!data.pro_price) {
      setError('Product price is required.');
      return false;
    }
    if (isNaN(data.pro_price) || Number(data.pro_price) <= 0) {
      setError('Product price must be a number greater than 0.');
      return false;
    }
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validate()) return;

    const formData = new FormData();
    formData.append('pro_name', data.pro_name.trim());
    formData.append('pro_price', data.pro_price);
    if (newImage) {
      formData.append('pro_image', newImage);
    }

    axios.put(`http://localhost:8000/product/${id}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
      .then(() => {
        setSuccess('Product updated successfully!');
        setTimeout(() => navigate('/'), 1500);
      })
      .catch(err => {
        setError('Failed to update product');
        console.error(err);
      });
  };

  if (loading) return <div className="container mt-4">Loading...</div>;

  return (
    <div className="container mt-4">
      <h2>Edit Product</h2>

      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label className="form-label">Product Name</label>
          <input
            type="text"
            name="pro_name"
            className="form-control"
            value={data.pro_name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Product Price</label>
          <input
            type="number"
            name="pro_price"
            className="form-control"
            value={data.pro_price}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Product Image</label>
          <input
            type="file"
            name="pro_image"
            className="form-control"
            onChange={handleImageChange}
            accept="image/*"
          />
          {imagePreview && (
            <img
              src={imagePreview}
              alt="Preview"
              style={{ marginTop: '10px', width: '120px', height: 'auto', border: '1px solid #ccc' }}
            />
          )}
        </div>

        <button type="submit" className="btn btn-primary">Update Product</button>
      </form>
    </div>
  );
};

export default EditProduct;
