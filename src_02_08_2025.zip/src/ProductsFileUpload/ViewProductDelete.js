import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const ViewProductDelete = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = () => {
    axios.get('http://localhost:8000/product')
      .then(res => {
        setProducts(res.data);
        setFilteredProducts(res.data);
      })
      .catch(err => console.error('Failed to fetch products', err));
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      axios.delete(`http://localhost:8000/product/${id}`)
        .then(() => {
          setMessage('Product deleted successfully.');
          const updated = products.filter(p => p.pro_id !== id);
          setProducts(updated);
          setFilteredProducts(updated);
        })
        .catch(err => {
          setMessage('Failed to delete product.');
          console.error(err);
        });
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearch(value);
    const filtered = products.filter(product =>
      product.pro_name.toLowerCase().includes(value)
    );
    setFilteredProducts(filtered);
  };

  return (
    <div className="container mt-4">
      <h2>Product List</h2>

      {message && <div className="alert alert-info">{message}</div>}

      <div className="d-flex justify-content-between mb-3">
        <Link to="/add" className="btn btn-success">Add Product</Link>
        <input
          type="text"
          className="form-control w-50"
          placeholder="Search by product name"
          value={search}
          onChange={handleSearch}
        />
      </div>

      {filteredProducts.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <table className="table table-bordered">
          <thead className="table-light">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Price</th>
              <th>Image</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.map(p => (
              <tr key={p.pro_id}>
                <td>{p.pro_id}</td>
                <td>{p.pro_name}</td>
                <td>{p.pro_price}</td>
                <td>
                  {p.pro_image ? (
                    <img
                      src={`http://localhost:8000${p.pro_image}`}
                      alt={p.pro_name}
                      width="80"
                      height="60"
                    />
                  ) : (
                    'No Image'
                  )}
                </td>
                <td>
                  <Link to={`/edit/${p.pro_id}`} className="btn btn-primary btn-sm me-2">Edit</Link>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p.pro_id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ViewProductDelete;
