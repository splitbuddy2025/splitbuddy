// src/components/InsertEmployee.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const InsertEmployee = () => {
  const [formData, setFormData] = useState({ Emp_no: '', Ename: '', Salary: '' });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8000/employee', formData);
      alert('Employee inserted successfully');
      setFormData({ Emp_no: '', Ename: '', Salary: '' });
      navigate('/view');
    } catch (error) {
      console.error(error);
      alert('Error submitting form: ' + error.message);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Insert New Employee</h2>
      <form onSubmit={handleSubmit} className="border p-4 shadow-sm rounded bg-light">
        <div className="form-group">
          <label>Emp No</label>
          <input
            type="text"
            className="form-control"
            name="Emp_no"
            value={formData.Emp_no}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            className="form-control"
            name="Ename"
            value={formData.Ename}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Salary</label>
          <input
            type="number"
            className="form-control"
            name="Salary"
            value={formData.Salary}
            onChange={handleChange}
            required
          />
        </div>
        <br/>
        <button type="submit" className="btn btn-success mr-2">Insert</button><br/>
        <br/>
        <button type="button" className="btn btn-secondary" onClick={() => navigate('/view')}>Cancel</button>
      </form>
    </div>
  );
};

export default InsertEmployee;
