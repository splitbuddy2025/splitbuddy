// src/components/ViewEmployees.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Make sure this is imported globally too

const ViewEmployees = () => {
  const [employees, setEmployees] = useState([]);
  const navigate = useNavigate();

  const fetchEmployees = async () => {
    try {
      const response = await axios.get('http://localhost:8000/employee');
      setEmployees(response.data);
    } catch (error) {
      console.error('Fetch Error:', error.message);
    }
  };

  const handleDelete = async (Emp_no) => {
    if (!window.confirm('Are you sure you want to delete this employee?')) return;
    try {
      await axios.delete(`http://localhost:8000/employee/${Emp_no}`);
      alert('Employee deleted successfully');
      fetchEmployees();
    } catch (error) {
      alert('Delete failed: ' + error.message);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Employee List</h2>
        <button className="btn btn-success" onClick={() => navigate('/insert')}>
          Add New Employee
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-bordered table-striped table-hover">
          <thead className="thead-dark">
            <tr>
              <th>Emp No</th>
              <th>Name</th>
              <th>Salary</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.map(emp => (
              <tr key={emp.Emp_no}>
                <td>{emp.Emp_no}</td>
                <td>{emp.Ename}</td>
                <td>{emp.Salary}</td>
                <td>
                  <button
                    className="btn btn-warning btn-sm mr-2"
                    onClick={() => navigate(`/edit/${emp.Emp_no}`)}
                  >
                    Edit
                  </button>
                  &nbsp; &nbsp;
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(emp.Emp_no)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {employees.length === 0 && (
              <tr>
                <td colSpan="4" className="text-center text-muted">No records found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ViewEmployees;
