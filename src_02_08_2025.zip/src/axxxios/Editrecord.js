import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const Editrecord = () => {
  const { empId } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    Emp_no: '',
    Ename: '',
    Salary: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:8000/employee/${empId}`);
        if (res.data && typeof res.data === 'object') {
          setFormData(res.data);
        } else {
          alert('No data found for this employee.');
        }
      } catch (err) {
        alert('Error fetching employee: ' + err.message);
      }
    };

    fetchData();
  }, [empId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:8000/employee/${empId}`, formData);
      alert('Employee updated successfully');
      navigate('/view');
    } catch (error) {
      alert('Update failed: ' + error.message);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Edit Employee</h2>
      <form onSubmit={handleUpdate} className="border p-4 shadow-sm rounded bg-light">
        <div className="form-group">
          <label>Emp No</label>
          <input
            type="text"
            className="form-control"
            name="Emp_no"
            value={formData.Emp_no}
            readOnly
          />
        </div>
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            className="form-control"
            name="Ename"
            value={formData.Ename}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Salary</label>
          <input
            type="number"
            className="form-control"
            name="Salary"
            value={formData.Salary}
            onChange={handleChange}
            required
          />
        </div>
        <br/>
        <button type="submit" className="btn btn-primary mr-2">Update</button><br/>
        <br/>
        <button type="button" className="btn btn-secondary" onClick={() => navigate('/view')}>Cancel</button>
      </form>
      
    </div>
  );
};

export default Editrecord;
