import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Apiex = () => {
  const [result, setResult] = useState([]);

  const getData = () => {
    axios.get("http://localhost:8000/Employee")
      .then(response => {
        setResult(response.data);
        console.log(response.data);
      })
      .catch(error => {
        console.error("Error fetching data:", error);
      });
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <center>
      <div className='col-sm-6'>
        <br /><br /><br />
        <table className="table table-striped" border="1">
          <thead>
            <tr>
              <th>Emp_no</th>
              <th>Ename</th>
              <th>Salary</th>
            </tr>
          </thead>
          <tbody>
            {result.map((data, index) =>
              <tr key={index}>
                <td>{data.Emp_no}</td>
                <td>{data.Ename}</td>
                <td>{data.Salary}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </center>
  );
};

export default Apiex;
