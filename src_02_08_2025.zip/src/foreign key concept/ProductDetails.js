import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const MobileList = () => {
  const [mobiles, setMobiles] = useState([]);
  const [filteredMobiles, setFilteredMobiles] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchMobiles();
  }, []);

  const fetchMobiles = async () => {
    try {
      const res = await axios.get('http://localhost:4000/mobile/view', { withCredentials: true });
      const sorted = res.data.sort((a, b) => a.m_id - b.m_id);
      setMobiles(sorted);
      setFilteredMobiles(sorted);
    } catch (err) {
      console.error('Error fetching mobiles:', err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this mobile?')) return;
    try {
      await axios.delete(`http://localhost:4000/mobile/${id}`, { withCredentials: true });
      fetchMobiles();
    } catch (err) {
      console.error('Delete error:', err.message);
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchTerm(value);
    const filtered = mobiles.filter(mob =>
      mob.model_no.toLowerCase().includes(value)
    );
    setFilteredMobiles(filtered);
  };

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:4000/logout', {}, { withCredentials: true });
      sessionStorage.removeItem('loggedInUser');
      navigate('/');
    } catch (err) {
      console.error('Logout error:', err.message);
      alert('Logout failed');
    }
  };

  return (
    <div className="container mt-4">

      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-light bg-light mb-4">
        <div className="container-fluid">
          <span className="navbar-brand">Product Manager</span>
          <div className="collapse navbar-collapse">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <button className="nav-link btn btn-link" onClick={() => navigate('/brand/view')}>
                  Brands
                </button>
              </li>
              <li className="nav-item">
                <button className="nav-link btn btn-link" onClick={() => navigate('/mobile')}>
                  Products
                </button>
              </li>
            </ul>
            <button className="btn btn-outline-danger" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </div>
      </nav>

      <h2>Mobile List</h2>

      {/* Search + Add button row */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <input
          type="text"
          className="form-control w-50"
          placeholder="Search by model number"
          value={searchTerm}
          onChange={handleSearch}
        />

        <button className="btn btn-success ms-3" onClick={() => navigate('/mobile/insert')}>
          Insert New Product
        </button>
      </div>

      {/* Product Table */}
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Images</th>
            <th>Model</th>
            <th>Price</th>
            <th>Brand</th>
            <th>Features</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredMobiles.map(mob => (
            <tr key={mob.m_id}>
              <td>
                {mob.image
                  ? mob.image.split(',').map((img, index) => (
                    <img
                      key={index}
                      src={`http://localhost:4000/upload/${img}`}
                      width="60"
                      height="60"
                      alt={`mobile-${index}`}
                      className="me-1 mb-1"
                    />
                  ))
                  : 'No Image'}
              </td>
              <td>{mob.model_no}</td>
              <td>{mob.price}</td>
              <td>{mob.brand_name}</td>
              <td>{mob.features}</td>
              <td>
                <button
                  className="btn btn-warning btn-sm me-2"
                  onClick={() => navigate(`/mobile/edit/${mob.m_id}`)}
                >
                  Edit
                </button>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleDelete(mob.m_id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MobileList;