import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const BrandList = () => {
  const [brands, setBrands] = useState([]);
  const navigate = useNavigate();

  const fetchBrands = async () => {
    try {
      const res = await axios.get('http://localhost:4000/brand/view', { withCredentials: true });
      setBrands(res.data);
    } catch (err) {
      console.error('Fetch error:', err.message);
    }
  };

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:4000/logout', {}, { withCredentials: true });
      sessionStorage.removeItem('loggedInUser');
      navigate('/');
    } catch (err) {
      console.error('Logout error:', err.message);
      alert('Logout failed');
    }
  };

  useEffect(() => {
    fetchBrands();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this brand?')) return;
    await axios.delete(`http://localhost:4000/brand/delete/${id}`);
    fetchBrands();
  };

  return (
    <div className="container mt-4">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-light bg-light mb-4">
        <div className="container-fluid">
          <span className="navbar-brand">Product Manager</span>
          <div className="collapse navbar-collapse">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <button className="nav-link btn btn-link" onClick={() => navigate('/brand/view')}>Brands</button>
              </li>
              <li className="nav-item">
                <button className="nav-link btn btn-link" onClick={() => navigate('/mobile')}>Products</button>
              </li>
            </ul>
            <button className="btn btn-outline-danger ms-auto" onClick={handleLogout}>Logout</button>
          </div>
        </div>
      </nav>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Brand List</h2>
        <button className="btn btn-primary" onClick={() => navigate('/brand/insert')}>
          Add New Brand
        </button>
      </div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Logo</th>
            <th>Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {brands.map(brand => (
            <tr key={brand.b_id}>
              <td>
                {brand.b_logo ? (
                  <img src={`http://localhost:4000/upload/${brand.b_logo}`} className='img-circle' width="60" height="60" alt="logo" />
                ) : 'No Image'}
              </td>
              <td>{brand.b_name}</td>
              <td>
                <button className="btn btn-warning btn-sm me-2" onClick={() => navigate(`/brand/edit/${brand.b_id}`)}>Edit</button>
                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(brand.b_id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BrandList;