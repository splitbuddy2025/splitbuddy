import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

function Login() {
  const [formData, setFormData] = useState({ remail: "", rpassword: "" });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: "" }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { remail, rpassword } = formData;

    if (!remail || !rpassword) {
      setErrors({
        remail: !remail ? "Email required" : "",
        rpassword: !rpassword ? "Password required" : ""
      });
      return;
    }

    try {
      const res = await fetch("http://localhost:4000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
        credentials: "include"
      });
      const result = await res.json();

      if (res.ok) {
        sessionStorage.setItem("loggedInUser", JSON.stringify(result.user));
        navigate("/brand/view");
      } else {
        alert(result.message);
      }
    } catch (err) {
      alert("Server error");
    }
  };

  return (
    <div className="container mt-5" style={{ maxWidth: "500px" }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Email</label>
          <input
            type="email"
            name="remail"
            className={`form-control ${errors.remail && "is-invalid"}`}
            value={formData.remail}
            onChange={handleChange}
          />
          <div className="invalid-feedback">{errors.remail}</div>
        </div>
        <div className="mb-3">
          <label>Password</label>
          <input
            type="password"
            name="rpassword"
            className={`form-control ${errors.rpassword && "is-invalid"}`}
            value={formData.rpassword}
            onChange={handleChange}
          />
          <div className="invalid-feedback">{errors.rpassword}</div>
        </div>
        <button className="btn btn-primary w-100">Login</button>
      </form>
      <p className="mt-3">New user? <Link to="/register">Register here</Link></p>
    </div>
  );
}

export default Login;