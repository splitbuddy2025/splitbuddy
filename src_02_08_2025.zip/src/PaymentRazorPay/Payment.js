import React from "react";
import axios from "axios";

const Payment = () => {
  const loadRazorpay = async () => {
    try {
      const result = await axios.post("http://localhost:5000/create-order", {
        amount: 500, // ₹500
      });

      const { id: order_id, amount } = result.data;

      const options = {
        key: "rzp_test_ughhWElb2p782f",
        amount: amount, // from backend (in paise)
        currency: "INR",
        name: "SplitBuddy",
        description: "Test Transaction",
        order_id: order_id,
        handler: function (response) {
          alert("Payment ID: " + response.razorpay_payment_id);
          alert("Order ID: " + response.razorpay_order_id);
          alert("Signature: " + response.razorpay_signature);
          // Optionally, send these to backend for verification
        },
        prefill: {
          name: "Neel Udhanwala",
          email: "splitbuddy2025@gmail.com",
          contact: "8758176552",
        },
        theme: {
          color: "#3399cc",
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      alert("Something went wrong while initiating payment");
      console.error(err);
    }
  };

  return <button onClick={loadRazorpay}>Pay ₹500</button>;
};

export default Payment;
