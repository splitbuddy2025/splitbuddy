// src/Admin/Admin.js
import React from 'react';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import Dashboard from './Dashboard';
import User from './User';
import Report from './Report';
import Setting from './Setting';
import NotFound from './NotFound';
import { Routes, Route } from 'react-router-dom';

const Admin = () => {
  return (
    <div>
      <Navbar />
      <div className="d-flex">
        <Sidebar />
        <main className="p-4" style={{ marginLeft: '200px', width: '100%' }}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/User" element={<User />} />
            <Route path="/Report" element={<Report />} />
            <Route path="/Setting" element={<Setting />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default Admin;
