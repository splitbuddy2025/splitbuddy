import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';
import Payment from './PaymentRazorPay/Payment';



// import ProductBrand from './foreign key concept/ProductBrand';
// import ProductBrandFom from './foreign key concept/ProductBrandFom';
// import ProductDetails from './foreign key concept/ProductDetails';
// import ProductForm from './foreign key concept/ProductForm';
// import Registration  from './foreign key concept/Registration';
// import Login from './foreign key concept/Login';

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        {/* <Route path='/' element={<Login/>}/>
        <Route path='/register' element={<Registration/>}/>
        <Route path='/brand/view' element={<ProductBrand/>}/>
        <Route path='/brand/insert' element={<ProductBrandFom/>}/>
        <Route path='/brand/edit/:id' element={<ProductBrandFom/>}/>
        <Route path='/mobile' element={<ProductDetails/>}/>
        <Route path='/mobile/insert' element={<ProductForm/>}/>
        <Route path='/mobile/edit/:id' element={<ProductForm/>}/> */}
        {/* <Route path='/product-form' element={<FileUpload/>}/>
        <Route path='/product-form/:p_id' element={<FileUpload/>}/>
        <Route path='/' element={<ShowProduct/>}/> */}
        {/* <Route path="/" element={<CourseList />} />
        <Route path="/course-form" element={<InsertCourse />} />
        <Route path="/course-form/:courseId" element={<InsertCourse />} /> */}
        {/* <Route exact path="/" element={<InsertEmp />} />
        <Route exact path="/employee/:id" element={<UpdateDemo />} /> */}
        {/* <Route exact path="/" element={<Login />} />
        <Route exact path="/homee" element={<Home />} />
        <Route exact path="/about" element={<About />} />
        <Route exact path="/contact" element={<Contact />} />
        <Route exact path="/ProductGallery" element={<ProductGallery />} />
        <Route exact path="/viewcart" element={<ViewCart />} /> */}
        {/* <Route exact path="/employee" element={<SampleJSONAxios />} />  */}


        <Route path='/' element={<Payment/>}/>

      </Routes>

    </BrowserRouter>
  </React.StrictMode>
);
