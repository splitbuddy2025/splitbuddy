// import React from 'react';
//import { useLocation, Link } from 'react-router-dom';
import './navbar.css'; // Custom CSS file for styles

// export default function UserDashboard() {
//     const location = useLocation();

//     return (
//         <div className="home-page">
//             {/* Gradient Background */}
//             <div className="background">
//                 {/* Glassmorphic Navbar */}
//                 <div className="glass-navbar">
//                     <ul className="nav-links">
//                         <li><Link to="/" className="nav-item">HOME</Link></li>
//                         <li><Link to="/User/about" className="nav-item">ABOUT</Link></li>
                       
//                         <li><Link to="/User/contact" className="nav-item">CONTACT</Link></li>
//                         <li><Link to="/User/ProductGallery" className="nav-item">PRODUCTGALLERY</Link></li>
//                     </ul>
//                 </div>

//                 {/* Welcome Section */}
//                 <div className="welcome-section">
//                     <h1>Welcome...</h1>
//                     <div><b>{location.state?.user}</b></div>
//                 </div>
//             </div>
//         </div>
//     );
// }



// src/Admin/Admin.js
import React from 'react';
//import Navbar from '../components/Navbar';
//import Sidebar from '../components/Sidebar';
import Home from './Home';
import Contact from './Contact';
import About from './About';
import ProductGallery from './ProductGallery';
import ViewCart from './ViewCart';
import { Routes, Route } from 'react-router-dom';

const UserDashboard = () => {
  return (
    <div>
      {/* //<Navbar />
      <div className="d-flex">
        <Sidebar />
        <main className="p-4" style={{ marginLeft: '200px', width: '100%' }}> */}
          <Routes>
            <Route path="/UserHome/" element={<Home />} />
            <Route path="/Contact" element={<Contact />} />
            <Route path="/About" element={<About />} />
            <Route path="/ProductGallery" element={<ProductGallery />} />
            <Route path="/ViewCart" element={<ViewCart />} />
          </Routes>
        {/* </main>
      </div> */}
    </div>
  );
};

export default UserDashboard;
