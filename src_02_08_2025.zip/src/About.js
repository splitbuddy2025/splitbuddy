import React from 'react';

const About = () => {
    return (
        <div>
          <h1>About US</h1>  
        </div>
    );
};

export default About;
