import React, { useState } from 'react';

const Hotel = () => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('order'); // default to "order"
  const [selectedServices, setSelectedServices] = useState([]);

  const services = ['food', 'accommodation', 'laundry'];
  const servicePrices = {
    food: 5000,
    accommodation: 15000,
    laundry: 2000,
  };

  const handleServiceChange = (event) => {
    const value = event.target.value;
    let updatedServices = [...selectedServices];

    if (event.target.checked) {
      updatedServices.push(value);
    } else {
      updatedServices = updatedServices.filter(item => item !== value);
    }

    setSelectedServices(updatedServices);
  };

  const calculateTotalPrice = () => {
    let total = selectedServices.reduce((sum, service) => {
      return sum + servicePrices[service];
    }, 0);

    if (category === 'reserved') {
      total *= 0.75; // apply 25% discount
    }

    return total;
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px' }}>
      <h3>Customer Service Form</h3>

      <div>
        <label>Name: </label>
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter name"
        />
      </div>

      <div style={{ marginTop: '10px' }}>
        <label>Category: </label>
        <label>
          <input 
            type="radio" 
            value="order" 
            checked={category === 'order'}
            onChange={(e) => setCategory(e.target.value)} 
          />
          Order
        </label>
        <label>
          <input 
            type="radio" 
            value="reserved" 
            checked={category === 'reserved'}
            onChange={(e) => setCategory(e.target.value)} 
          />
          Reserved
        </label>
      </div>

      <div style={{ marginTop: '10px' }}>
        <label>Services:</label>
        {services.map((service) => (
          <div key={service}>
            <input
              type="checkbox"
              value={service}
              checked={selectedServices.includes(service)}
              onChange={handleServiceChange}
            />
            <span>{service} - ₹{servicePrices[service]}</span>
          </div>
        ))}
      </div>

      <div style={{ marginTop: '10px' }}>
        <strong>Total Price:</strong> ₹{calculateTotalPrice()}
      </div>
    </div>
  );
};

export default Hotel;
