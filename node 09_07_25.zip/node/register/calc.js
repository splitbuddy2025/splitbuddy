var express = require('express');
var app = express();


var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));


app.get('/', function (req, res) {
    res.sendFile(__dirname +'/calc.html');
});

app.post('/submit-data', function (req, res) {
    console.log(req.body)
    var user = req.body.uname;
    var pass= req.body.pass;
    if (user=="mscit" && pass=="easy")
        res.sendFile(__dirname+"/calculater.html");
    else
        res.send("Verify User");
});


app.get("/calculater",function(req,res)
{
res.sendFile(__dirname+"/calc.html")
});


app.post('/submit_intrest', function (req, res) {
   // console.log(req.body)

    var p = req.body.p;
    var n= req.body.n;
    var r= req.body.r;

   
    var interest = (p*n*r)/100;
   res.send(interest);
});

var server = app.listen(9000, function () {
    console.log('server is running..9000');
});