const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Enable files upload
app.use(fileUpload());

// Serve static files from the "uploads" folder
app.use(express.static('uploads'));

// Serve HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'fileuploadform.html'));
});

// Handle file upload
app.post('/upload', (req, res) => {
    if (!req.files || !req.files.image) {
        return res.status(400).send('No image file was uploaded.');
    }

    const file = req.files.image;

    // Validate extension
    const allowedTypes = ['.jpg', '.jpeg', '.png'];
    const ext = path.extname(file.name).toLowerCase();
    if (!allowedTypes.includes(ext)) {
        return res.status(400).send('Only JPG and PNG files are allowed.');
    }

    const uploadPath = path.join(__dirname, 'uploads', file.name);

    file.mv(uploadPath, (err) => {
        if (err) return res.status(500).send(err);
        res.send('Image uploaded successfully.');
    });
});

// Download endpoint
app.get('/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);

    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.status(404).send('File not found.');
        }
        res.download(filePath);
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
