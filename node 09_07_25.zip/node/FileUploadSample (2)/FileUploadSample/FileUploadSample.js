var express = require('express')
var bodyParser= require('body-parser')
var multer = require('multer');
 
var app = express()

var path=require("path");
var ejs=require("ejs");

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'app/views'));

app.use(bodyParser.urlencoded({extended: true}))
app.use("/css",express.static(__dirname+"/app/public/css"));
app.use("/myimg",express.static(__dirname+"/app/public/Images"));
// parse application/json
app.use(bodyParser.json())

 // ROUTES
app.get('/',function(req,res){
  res.render('index.ejs');
 
});

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'upload')
  },
  filename: function (req, file, cb) {
    console.log(file);
   // cb(null, file.fieldname + '-' + Date.now())
   cb(null, file.originalname)
  }
})
 
var upload = multer({ storage: storage })


app.post('/uploadfile', upload.single('myFile'), (req, res, next) => {
  var file = req.file
  if (!file) {
    var error = new Error('Please upload a file')
    error.httpStatusCode = 400
    return next(error)
  }
    res.send(file)
  
})

app.post('/upload/photo', upload.single('myImage'), (req, res, next) => {
  var file = req.file
  if (!file) {
    var error = new Error('Please upload a file')
    error.httpStatusCode = 400
    return next(error)
  }
    res.send(file)
  
})
app.post('/uploadmultiple', upload.array('myFiles', 12), (req, res, next) => {
  var files = req.files
  if (!files) {
    var error = new Error('Please choose files')
    error.httpStatusCode = 400
    return next(error)
  }
 
    res.send(files)
  
})
//ROUTES WILL GO HERE
app.get('/', function(req, res) {
    res.json({ message: 'WELCOME' });   
});
 

// listen for requests
app.listen(3000, () => {
  console.log("Server is listening on port 3000");
});

