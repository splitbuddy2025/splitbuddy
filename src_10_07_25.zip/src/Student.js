import React, { useState } from 'react';

function Student() {
  const [formData, setFormData] = useState({
        enroll: '',
    uname: '',
    gender: '',
    language: {
      hindi: false,
      english: false,
      gujarati: false,
    },
  });
  var [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((cb) => ({
      ...cb,
      [name]: type === 'checkbox' ? checked : value,
      //language: type === 'checkbox' ? { ...cb.skills, [name]: checked } : cb.skills,
    }));
  };

  
  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    const { enroll,uname, gender, language } = formData;
    console.log({
        enroll,
      uname,
      gender,
      language,
    });
  };

  return (
    <div className="App">
      <h1>Student Form</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Enroll No: </label>
          <input type="enroll" name="enroll" value={formData.enroll} onChange={handleChange} required />
        </div>
        <div>
          <label>Username: </label>
          <input type="text" name="uname" value={formData.uname} onChange={handleChange} required />
        </div>
        <div>
          <label>Gender: </label>
          <input type="radio" name="gender" value="Male" onChange={handleChange} /> Male
          <input type="radio" name="gender" value="Female" onChange={handleChange} /> Female
        </div>
       <div>
        <label>Language: </label>
        <select name="language" value={formData.language} onChange={handleChange} required>
            <option value="">Select a language</option>
            <option value="Hindi">Hindi</option>
            <option value="English">English</option>
            <option value="Gujarati">Gujarati</option>
        </select>
        </div>

        
        <button type="submit">Register</button>
      </form>

      {submitted && (
        <div>
          <h2>Registration Data:</h2>
          <p>Enroll No: {formData.enroll}</p>
          <p>Username: {formData.uname}</p>
          <p>Gender: {formData.gender}</p>
          <p>Language: {formData.language}</p>
        </div>
      )}
      
    </div>
  );
}



export default Student;
