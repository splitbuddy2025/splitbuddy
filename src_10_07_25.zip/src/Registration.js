import React, { useState } from 'react';

function Registration() {
  const [formData, setFormData] = useState({
    uname: '',
    pwd: '',
    email: '',
    cno: '',
    gender: '',
    skills: {
      hindi: false,
      english: false,
      gujarati: false,
    },
    city: '',
  });
  var [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((cb) => ({
      ...cb,
      [name]: type === 'checkbox' ? checked : value,
      skills: type === 'checkbox' ? { ...cb.skills, [name]: checked } : cb.skills,
    }));
  };

  
  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    const { uname, pwd, email, cno, gender, skills, city } = formData;
    console.log({
      uname,
      pwd,
      email,
      cno,
      gender,
      skills: Object.entries(skills).filter(([_, value]) => value).map(([key, _]) => key),
      city,
    });
  };

  return (
    <div className="App">
      <h1>Registration Form</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username: </label>
          <input type="text" name="uname" value={formData.uname} onChange={handleChange} required />
        </div>
        <div>
          <label>Password: </label>
          <input type="password" name="pwd" value={formData.pwd} onChange={handleChange} required />
        </div>
        <div>
          <label>Email: </label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        </div>
        <div>
          <label>Contact Number: </label>
          <input type="text" name="cno" value={formData.cno} onChange={handleChange} required />
        </div>
        <div>
          <label>Gender: </label>
          <input type="radio" name="gender" value="male" onChange={handleChange} /> Male
          <input type="radio" name="gender" value="female" onChange={handleChange} /> Female
        </div>
        <div>
          <label>Skills: </label>
          <input type="checkbox" name="hindi" checked={formData.skills.hindi} onChange={handleChange} /> Hindi
          <input type="checkbox" name="english" checked={formData.skills.english} onChange={handleChange} /> English
          <input type="checkbox" name="gujarati" checked={formData.skills.gujarati} onChange={handleChange} /> Gujarati
        </div>
        <div>
          <label>City: </label>
          <select name="city" value={formData.city} onChange={handleChange} required>
            <option value="">Select a city</option>
            <option value="Mumbai">Mumbai</option>
            <option value="Delhi">Delhi</option>
            <option value="Ahmedabad">Ahmedabad</option>
          </select>
        </div>
        <button type="submit">Register</button>
      </form>

      {submitted && (
        <div>
          <h2>Registration Data:</h2>
          <p>Username: {formData.uname}</p>
          <p>Password: {formData.pwd}</p>
          <p>Email: {formData.email}</p>
          <p>Contact Number: {formData.cno}</p>
          <p>Gender: {formData.gender}</p>
          <p>Skills: {Object.entries(formData.skills).filter(([_, value]) => value).map(([key, _]) => key).join(', ')}</p>
          <p>City: {formData.city}</p>
        </div>
      )}
      
    </div>
  );
}



export default Registration;
