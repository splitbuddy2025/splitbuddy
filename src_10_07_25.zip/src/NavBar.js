import React from 'react';
import { Navbar, Nav, Button } from 'react-bootstrap';

const NavBar = () => {
  return (
    <div>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
        <Nav className="me-auto"> {/* Updated from 'mr-auto' to 'me-auto' */}
          <Nav.Link href="#home">Home</Nav.Link>
          <Nav.Link href="#features">Features</Nav.Link>
          <Nav.Link href="#pricing">Pricing</Nav.Link>
        </Nav>
      </Navbar>
      <Button variant="primary">Click Me!</Button>
    </div>
  );
}

export default NavBar;