import React, { useState } from 'react';

const CheckBox_Fruits = () => {
    
    const [checked, setChecked] = useState([]);
    const checkList = ["mango","kiwi","lichi","banana","strawberry"];
    const checkPrice =[20,40,30,50,40];
    
    
    const handleCheck = (event) => {
        var updatedList = [...checked];
        if(event.target.checked){
            updatedList = [...checked,event.target.value];
        } else {
            updatedList.splice(checked.indexOf(event.target.value), 1);
        }
        setChecked(updatedList);
    }
   // total=total+","+item
    const checkedItems = checked.length
    ? checked.reduce((total, item) => {
        return total + ", " + item;
      })
    : "";

    //total=total+checkPrice[index]
    const totalPrice = checked.reduce((total, item) => {
        //reduce is in-built function which has 2 properties in which 1st indicates that it stores the sum of array and second represents a current number
        const index = checkList.indexOf(item);
        if (index !== -1) {
            return total + checkPrice[index];
        }
        return total;
    }, 0);

    return (
        <div>
            <div>
                <div>Your Check List : </div>
                <div>
                    {checkList.map((item, index) => (
                        <div key={index}>
                            <input value={item} type="checkbox" onChange={handleCheck}/>
                            <span>{item}</span>
                            <span> - {checkPrice[index]}</span>
                        </div>
                    ))}
                </div>
            </div>
            <div>
        {`Items checked are: ${checkedItems}`}
      </div>

      <div>
                {`Total Price: ${totalPrice}`}
            </div>
      
    </div>
    );
};

export default CheckBox_Fruits;