import React from "react";
import { Link } from "react-router-dom";
import { FaChartPie, FaUsers, FaUserCog, FaQuestionCircle, FaUsersCog, FaDownload, FaEdit } from "react-icons/fa";

export default function Sidebar({ user }) {
  return (
    <div
      className="col-md-3 col-lg-2 bg-dark text-white d-flex flex-column p-3 vh-100 shadow"
      style={{ position: "sticky", top: 0 }}
    >
      {/* Title
      <h4 className="fw-bold mb-4 text-center">⚡ Admin Panel</h4> */}

      {/* Navigation Links */}
      <nav className="nav flex-column mb-auto">
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/overview">
          <FaChartPie /> Overview
        </Link>
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/activeusers">
          <FaUsers /> Active Users
        </Link>
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/usermanagement">
          <FaUserCog /> User Management
        </Link>
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/queries">
          <FaQuestionCircle /> Queries
        </Link>
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/groupmonitoring">
          <FaUsersCog /> Group Monitoring
        </Link>
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/exportdata">
          <FaDownload /> Export Data
        </Link>
        <Link className="nav-link text-white d-flex align-items-center gap-2 py-2" to="/contentmanagement">
          <FaEdit /> Content Management
        </Link>
      </nav>
    </div>
  );
}
