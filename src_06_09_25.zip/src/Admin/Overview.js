import React from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "./Header";

export default function Overview() {
  const user = JSON.parse(sessionStorage.getItem("loggedInUser"));

  return (
    <div className="container-fluid vh-100 p-0">
      {/* Header */}
      <Header user={user} />

      {/* Sidebar + Main Content */}
      <div className="row h-100 m-0">
        {/* Sidebar */}
        <Sidebar user={user} />

        {/* Main content */}
        <div className="col-md-9 col-lg-10 p-4">
          <h2>Welcome, {user?.name || "Admin"} 👋</h2>
          <p className="text-muted">Here’s what’s happening today:</p>

          {/* Quick Stats */}
          <div className="row mb-4">
            <div className="col-md-4">
              <div className="card shadow-sm p-3">
                <h5>Total Users</h5>
                <p className="fs-4 fw-bold">1,245</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card shadow-sm p-3">
                <h5>Active Groups</h5>
                <p className="fs-4 fw-bold">320</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card shadow-sm p-3">
                <h5>Pending Queries</h5>
                <p className="fs-4 fw-bold">18</p>
              </div>
            </div>
          </div>

          {/* Placeholder for Child Pages */}
          <Outlet />

          {/* Extra Content */}
          <div className="mt-4">
            <h4>Recent Activity</h4>
            <ul>
              <li>User <strong>John Doe</strong> joined Group A</li>
              <li>Query from <strong>Jane Smith</strong> resolved</li>
              <li>New group <strong>Tech Talk</strong> created</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
