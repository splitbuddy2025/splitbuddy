import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom"; // For navigation
import UserHeader from "./UserHeader";

export default function Groups() {
  const navigate = useNavigate();
  const user = JSON.parse(sessionStorage.getItem("loggedInUser"));
  const [groups, setGroups] = useState([]);
  const [members, setMembers] = useState({});
  const [showMembers, setShowMembers] = useState({});
  const [newGroupName, setNewGroupName] = useState("");
  const [joinGroupId, setJoinGroupId] = useState("");
  const [allUsers, setAllUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);

  // Fetch groups of current user
  const fetchGroups = useCallback(async () => {
    try {
      const res = await fetch(
        `http://localhost:4000/api/groups/user/${user.user_id}`
      );
      const data = await res.json();
      setGroups(data);
    } catch (err) {
      console.error("Failed to load groups", err);
    }
  }, [user.user_id]);

  // Fetch members of group
  const fetchMembers = useCallback(async (groupId) => {
    try {
      const res = await fetch(
        `http://localhost:4000/api/groups/${groupId}/members`
      );
      const data = await res.json();
      setMembers((prev) => ({ ...prev, [groupId]: data }));
    } catch (err) {
      console.error("Failed to load members", err);
    }
  }, []);

  // Fetch all users (for admin bulk add)
  const fetchAllUsers = useCallback(async () => {
    try {
      const res = await fetch("http://localhost:4000/api/users");
      const data = await res.json();
      setAllUsers(data);
    } catch (err) {
      console.error("Failed to load users", err);
    }
  }, []);

  // Load initial data
  useEffect(() => {
    fetchGroups();
    fetchAllUsers();
  }, [fetchGroups, fetchAllUsers]);

  // Create group
  const handleCreateGroup = async () => {
    try {
      await fetch("http://localhost:4000/api/groups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          group_name: newGroupName,
          created_by: user.user_id,
        }),
      });
      setNewGroupName("");
      fetchGroups();
    } catch (err) {
      console.error("Error creating group", err);
    }
  };

  // Join group by ID
  const handleJoinGroup = async () => {
    try {
      await fetch("http://localhost:4000/api/group_members", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ group_id: joinGroupId, user_id: user.user_id }),
      });
      setJoinGroupId("");
      fetchGroups();
    } catch (err) {
      console.error("Error joining group", err);
    }
  };

  // Delete group
  const handleDeleteGroup = async (groupId) => {
    try {
      await fetch(`http://localhost:4000/api/groups/${groupId}`, {
        method: "DELETE",
      });
      fetchGroups();
    } catch (err) {
      console.error("Error deleting group", err);
    }
  };

  // Delete member
  const handleDeleteMember = async (groupId, memberId) => {
    try {
      await fetch(
        `http://localhost:4000/api/groups/${groupId}/members/${memberId}`,
        { method: "DELETE" }
      );
      fetchMembers(groupId);
    } catch (err) {
      console.error("Error deleting member", err);
    }
  };

  // Bulk add members (admin only)
  const addMembers = async (groupId) => {
    try {
      for (let uid of selectedUsers) {
        await fetch(`http://localhost:4000/api/groups/${groupId}/join`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: uid }),
        });
      }
      setSelectedUsers([]);
      fetchMembers(groupId);
    } catch (err) {
      console.error(err);
    }
  };

  // Navigate to ExpensesAll page for a group
  const handleAddExpense = (groupId) => {
    navigate(`/expenses/${groupId}`); // Pass groupId in URL
  };

  return (
    <>
      <UserHeader />
      <div
        style={{
          textAlign: "center",
          padding: "30px",
          fontFamily: "Segoe UI, Arial, sans-serif",
          background: "#f4f7fb",
          minHeight: "100vh",
        }}
      >
        <h2 style={{ color: "#0056b3", marginBottom: "25px" }}>
          📂 Manage Groups
        </h2>

        {/* Create & Join */}
        <div style={{ marginBottom: "20px" }}>
          <input
            value={newGroupName}
            onChange={(e) => setNewGroupName(e.target.value)}
            placeholder="New group name"
            style={{
              padding: "10px",
              borderRadius: "6px",
              border: "1px solid #ccc",
              marginRight: "10px",
              width: "220px",
            }}
          />
          <button
            onClick={handleCreateGroup}
            style={{
              padding: "10px 16px",
              background: "#28a745",
              color: "white",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
            }}
          >
            ➕ Create
          </button>
        </div>

        <div style={{ marginBottom: "30px" }}>
          <input
            value={joinGroupId}
            onChange={(e) => setJoinGroupId(e.target.value)}
            placeholder="Enter group ID to join"
            style={{
              padding: "10px",
              borderRadius: "6px",
              border: "1px solid #ccc",
              marginRight: "10px",
              width: "220px",
            }}
          />
          <button
            onClick={handleJoinGroup}
            style={{
              padding: "10px 16px",
              background: "#17a2b8",
              color: "white",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
            }}
          >
            🔑 Join
          </button>
        </div>

        {/* Groups List */}
        {groups.map((g) => (
          <div
            key={g.group_id}
            style={{
              margin: "20px auto",
              padding: "20px",
              borderRadius: "12px",
              maxWidth: "700px",
              background: "white",
              boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
              textAlign: "left",
            }}
          >
            <h3 style={{ color: "#333", marginBottom: "8px" }}>{g.group_name}</h3>
            <p style={{ fontSize: "13px", color: "#777" }}>Group ID: {g.group_id}</p>

            {g.created_by === user.user_id && (
              <button
                onClick={() => handleDeleteGroup(g.group_id)}
                style={{
                  background: "#dc3545",
                  color: "white",
                  margin: "10px 8px 10px 0",
                  padding: "6px 14px",
                  borderRadius: "6px",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                🗑️ Delete Group
              </button>
            )}

            {/* Add Expense button */}
            <button
              onClick={() => handleAddExpense(g.group_id)}
              style={{
                background: "#ffc107",
                color: "white",
                padding: "6px 14px",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                marginRight: "8px",
              }}
            >
              💰 Add Expense
            </button>

            {/* Toggle members */}
            <button
              onClick={() => {
                setShowMembers((prev) => ({
                  ...prev,
                  [g.group_id]: !prev[g.group_id],
                }));
                if (!showMembers[g.group_id]) fetchMembers(g.group_id);
              }}
              style={{
                background: "#007bff",
                color: "white",
                padding: "6px 14px",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
              }}
            >
              {showMembers[g.group_id] ? "🙈 Hide Members" : "👥 Show Members"}
            </button>

            {showMembers[g.group_id] && (
              <div style={{ marginTop: "15px" }}>
                <h4 style={{ marginBottom: "10px", color: "#0056b3" }}>Members</h4>
                <ul style={{ paddingLeft: "20px" }}>
                  {members[g.group_id]?.map((m) => (
                    <li key={m.user_id} style={{ marginBottom: "8px", fontSize: "15px" }}>
                      {m.name} <span style={{ color: "#777" }}>({m.email})</span>
                      {g.created_by === user.user_id && m.user_id !== g.created_by && (
                        <button
                          onClick={() => handleDeleteMember(g.group_id, m.user_id)}
                          style={{
                            marginLeft: "12px",
                            background: "#ff4d4f",
                            color: "white",
                            borderRadius: "6px",
                            padding: "4px 10px",
                            border: "none",
                            cursor: "pointer",
                          }}
                        >
                          ❌ Remove
                        </button>
                      )}
                    </li>
                  ))}
                </ul>

                {g.created_by === user.user_id && (
                  <div style={{ marginTop: "20px" }}>
                    <h4 style={{ marginBottom: "10px" }}>➕ Add Members</h4>
                    <ul style={{ paddingLeft: "20px" }}>
                      {allUsers.map((u) => (
                        <li key={u.user_id} style={{ marginBottom: "6px" }}>
                          <label>
                            <input
                              type="checkbox"
                              checked={selectedUsers.includes(u.user_id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedUsers([...selectedUsers, u.user_id]);
                                } else {
                                  setSelectedUsers(selectedUsers.filter((id) => id !== u.user_id));
                                }
                              }}
                              style={{ marginRight: "6px" }}
                            />
                            {u.name} <span style={{ color: "#777" }}>({u.email})</span>
                          </label>
                        </li>
                      ))}
                    </ul>
                    <button
                      onClick={() => addMembers(g.group_id)}
                      style={{
                        marginTop: "10px",
                        background: "#28a745",
                        color: "white",
                        padding: "8px 16px",
                        borderRadius: "6px",
                        border: "none",
                        cursor: "pointer",
                      }}
                    >
                      ✅ Add Selected
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
