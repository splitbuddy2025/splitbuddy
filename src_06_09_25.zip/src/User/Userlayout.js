// src/User/UserLayout.js
import { Outlet } from "react-router-dom";
import UserSidebar from "./UserSidebar";
import UserHeader from "./UserHeader";

export default function UserLayout() {
  return (
    <div className="d-flex flex-column vh-100">
      {/* Header */}
      <UserHeader />

      <div className="d-flex flex-grow-1">
        {/* Sidebar */}
        {/* <div style={{ width: "250px" }}> */}
          {/* <UserSidebar /> */}
        {/* </div> */}

        {/* Page Content */}
        <div className="flex-grow-1 p-4">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
