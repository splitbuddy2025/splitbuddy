// src/User/Settings.js
import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import UserHeader from "./UserHeader";

export default function Settings() {
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [message, setMessage] = useState("");

  useEffect(() => {
    const u = sessionStorage.getItem("loggedInUser");
    if (u) {
      const parsed = JSON.parse(u);
      setUser(parsed);
      setForm({ name: parsed.name, email: parsed.email, password: "" });
    }
  }, []);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSave(e) {
    e.preventDefault();
    if (!user) return;

    try {
      const res = await fetch(`http://localhost:4000/api/users/${user.user_id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      if (!res.ok) throw new Error("Failed to update");

      const updated = await res.json();

      sessionStorage.setItem("loggedInUser", JSON.stringify(updated));
      setUser(updated);
      setMessage("✅ Profile updated successfully!");
    } catch (err) {
      console.error(err);
      setMessage("❌ Error updating profile.");
    }
  }

  if (!user) return <p className="p-3">Loading...</p>;

  return (
    <>
      <UserHeader />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          padding: "40px",
          background: "#f4f7fb",
          minHeight: "100vh",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "30px",
            boxShadow: "0 6px 18px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "500px",
          }}
        >
          <h2
            className="mb-4 text-center"
            style={{ color: "#0077ff", fontWeight: "bold" }}
          >
            ⚙️ Settings
          </h2>

          {message && (
            <div className="alert alert-info text-center">{message}</div>
          )}

          <form onSubmit={handleSave}>
            <div className="mb-3 text-start">
              <label className="form-label fw-bold">Name</label>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                className="form-control"
                placeholder="Enter your name"
              />
            </div>

            <div className="mb-3 text-start">
              <label className="form-label fw-bold">Email</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                className="form-control"
                placeholder="Enter your email"
              />
            </div>

            <div className="mb-3 text-start">
              <label className="form-label fw-bold">New Password</label>
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                className="form-control"
                placeholder="Leave blank to keep current password"
              />
            </div>

            <div className="d-grid">
              <button
                type="submit"
                className="btn btn-primary"
                style={{
                  background: "linear-gradient(90deg, #0077ff, #00c6ff)",
                  border: "none",
                  fontWeight: "600",
                }}
              >
                💾 Save Changes
              </button>
            </div>
          </form>
        </div>
      </div>
      <Outlet />
    </>
  );
}
