// src/User/BalancesPage.js
import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import UserHeader from "./UserHeader";

export default function BalancesPage() {
  const user = JSON.parse(sessionStorage.getItem("loggedInUser") || "null");
  const [balances, setBalances] = useState([]); // group balances
  const [total, setTotal] = useState(0); // total balance
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadBalances() {
      try {
        const res = await fetch(
          `http://localhost:4000/api/users/${user.user_id}/balance`
        );
        if (!res.ok) throw new Error("Failed to fetch balances");
        const data = await res.json();
        setBalances(data.groups || []); // groups from backend
        setTotal(data.totalBalance || 0); // total balance
      } catch (err) {
        console.error("Error fetching balances", err);
      } finally {
        setLoading(false);
      }
    }
    if (user?.user_id) loadBalances();
  }, [user]);

  return (
    <>
      <UserHeader />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          padding: "40px",
          background: "#f4f7fb",
          minHeight: "100vh",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "30px",
            boxShadow: "0 6px 18px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "700px",
          }}
        >
          <h2
            className="mb-4 text-center"
            style={{ color: "#0077ff", fontWeight: "bold" }}
          >
            ⚖️ Your Balances
          </h2>

          {loading ? (
            <p className="text-muted">Loading balances...</p>
          ) : balances.length === 0 ? (
            <p className="text-success fw-bold"> You are all settled up!</p>
          ) : (
            <ul className="list-group">
              {balances.map((bal) => (
                <li
                  key={bal.group_id}
                  className="list-group-item d-flex justify-content-between align-items-center"
                  style={{
                    border: "none",
                    borderBottom: "1px solid #eee",
                    padding: "14px 18px",
                    borderRadius: "8px",
                    marginBottom: "10px",
                    background:
                      bal.balance > 0
                        ? "linear-gradient(90deg, #e6f9ed, #d4f5e3)"
                        : bal.balance < 0
                        ? "linear-gradient(90deg, #fdecea, #fce3e1)"
                        : "#f8f9fa",
                  }}
                >
                  <span
                    style={{
                      color:
                        bal.balance > 0
                          ? "#28a745"
                          : bal.balance < 0
                          ? "#dc3545"
                          : "#6c757d",
                      fontWeight: 500,
                    }}
                  >
                    {bal.balance > 0
                      ? `You are owed in ${bal.group_name}`
                      : bal.balance < 0
                      ? `You owe in ${bal.group_name}`
                      : `Settled in ${bal.group_name}`}
                  </span>
                  <span
                    className="badge"
                    style={{
                      background:
                        bal.balance > 0
                          ? "linear-gradient(90deg, #28a745, #4cd964)"
                          : bal.balance < 0
                          ? "linear-gradient(90deg, #ff6b6b, #ff8787)"
                          : "#adb5bd",
                      color: "#fff",
                      fontSize: "0.9rem",
                      padding: "8px 14px",
                      borderRadius: "20px",
                      fontWeight: "600",
                    }}
                  >
                    ₹{Math.abs(parseFloat(bal.balance)).toFixed(2)}
                  </span>
                </li>
              ))}
            </ul>
          )}

          {/* Total Balance */}
          {!loading && (
            <h4 className="mt-4 text-center">
              Total Balance:{" "}
              {total > 0 ? (
                <span className="text-success">You are owed ₹{total.toFixed(2)}</span>
              ) : total < 0 ? (
                <span className="text-danger">You owe ₹{Math.abs(total).toFixed(2)}</span>
              ) : (
                <span className="text-muted">All settled</span>
              )}
            </h4>
          )}
        </div>
      </div>
      <Outlet />
    </>
  );
}
