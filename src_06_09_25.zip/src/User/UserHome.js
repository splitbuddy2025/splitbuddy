// src/User/UserHome.js
import { useEffect, useState } from "react";

export default function UserHome() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = sessionStorage.getItem("loggedInUser");
    if (u) {
      setUser(JSON.parse(u));
    }
  }, []);

  return (
    <div className="p-3">
      <h2 className="mb-3">Welcome {user?.name || "User"} 👋</h2>
      <p className="lead">
        This is your dashboard. From here you can manage your groups, add
        expenses, track balances, and settle up with friends.
      </p>

      <div className="row g-3 mt-4">
        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Groups</h5>
              <p className="card-text">
                View and manage your groups, or create new ones to share
                expenses.
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Expenses</h5>
              <p className="card-text">
                Add and review shared expenses inside your groups easily.
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Balances</h5>
              <p className="card-text">
                Check who owes who and keep track of settlements.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
