// src/User/ExpensesAll.js
import { useEffect, useState } from "react";
import { Outlet, useParams } from "react-router-dom";
import UserHeader from "./UserHeader";

export default function ExpensesAll() {
  const { groupId } = useParams();
  const [expenses, setExpenses] = useState([]);
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);
  const [groupName, setGroupName] = useState(""); 
  const user = JSON.parse(sessionStorage.getItem("loggedInUser") || "null");

  // Load expenses + group name
  useEffect(() => {
    async function loadData() {
      try {
        // fetch expenses
        const expRes = await fetch(`http://localhost:4000/api/expenses/${groupId}`);
        const expData = await expRes.json();
        setExpenses(expData);

        // fetch group info
        const groupRes = await fetch(`http://localhost:4000/api/groups/${groupId}`);
        const groupData = await groupRes.json();
        setGroupName(groupData.group_name);
      } catch (err) {
        console.error("Failed to load data", err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [groupId]);

  // Add new expense
  async function handleAddExpense() {
    if (!amount || !description) return;
    try {
      const res = await fetch("http://localhost:4000/api/expenses", { // ✅ fixed endpoint
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          group_id: groupId,
          paid_by: user.user_id,
          description,
          amount: parseFloat(amount),
        }),
      });

      if (!res.ok) throw new Error("Failed to add expense");
      const newExpense = await res.json();

      // Update local state with new expense
      setExpenses([...expenses, newExpense]);
      setAmount("");
      setDescription("");
    } catch (err) {
      console.error(err);
      alert("Error adding expense");
    }
  }

  if (loading) return <p className="p-3">Loading expenses...</p>;

  return (
    <>
      <UserHeader />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          padding: "40px",
          background: "#f4f7fb",
          minHeight: "100vh",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "30px",
            boxShadow: "0 6px 18px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "700px",
          }}
        >
          <h2
            className="mb-4 text-center"
            style={{ color: "#0077ff", fontWeight: "bold" }}
          >
            💰 {groupName || "Group"} Expenses
          </h2>

          {/* Add expense form */}
          <div
            className="card p-4 shadow-sm mb-4"
            style={{ borderRadius: "10px", border: "none" }}
          >
            <h5 className="mb-3" style={{ color: "#333" }}>
              ➕ Add Expense
            </h5>
            <input
              type="text"
              className="form-control mb-3"
              placeholder="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <input
              type="number"
              className="form-control mb-3"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <div className="d-grid">
              <button
                className="btn btn-success"
                onClick={handleAddExpense}
                style={{
                  background: "linear-gradient(90deg, #28a745, #4cd964)",
                  border: "none",
                  fontWeight: "600",
                }}
              >
                ➕ Add Expense
              </button>
            </div>
          </div>

          {/* Expense list */}
          <h5 className="mb-3" style={{ color: "#333" }}>
            📋 All Expenses
          </h5>
          {expenses.length === 0 ? (
            <p className="text-muted">No expenses yet in this group.</p>
          ) : (
            <ul className="list-group">
              {expenses.map((exp) => (
                <li
                  key={exp.expense_id}
                  className="list-group-item d-flex justify-content-between align-items-center"
                  style={{
                    border: "none",
                    borderBottom: "1px solid #eee",
                    padding: "12px 16px",
                  }}
                >
                  <div className="text-start">
                    <strong style={{ color: "#0077ff" }}>
                      {exp.description}
                    </strong>
                    <br />
                    <small className="text-muted">
                      Paid by User #{exp.paid_by}
                    </small>
                  </div>
                  <span
                    className="badge"
                    style={{
                      background: "linear-gradient(90deg, #0077ff, #00c6ff)",
                      fontSize: "0.9rem",
                      padding: "8px 12px",
                    }}
                  >
                    ₹{parseFloat(exp.amount).toFixed(2)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <Outlet />
    </>
  );
}
