// src/User/UserRoutes.js
import React, { useEffect, useState } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";

// User Layout (with Sidebar)
import UserLayout from "./Userlayout";

// User Pages
import UserHome from "./UserHome";
// import Groups from "./Groups";
// import GroupDetail from "./GroupDetail";
// import NewGroup from "./NewGroup";
// import ExpensesAll from "./ExpensesAll";
// import BalancesPage from "./BalancesPage";
// import SettleUpPage from "./SettleUpPage";
// import Settings from "./Settings";

export default function UserRoutes() {
  const [user, setUser] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const loggedInUser = sessionStorage.getItem("loggedInUser");
    setUser(loggedInUser ? JSON.parse(loggedInUser) : null);
  }, [location]);

  const isUser = user?.role === "user";

  return (
    <Routes>
     
    

      
      {/* <Route
        path="/UserHome"
        element={isUser ? <UserHome/> : <Navigate to="/login" replace />}
      />
      <Route
        path="/Groups"
        element={isUser ? <Groups /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/NewGroup"
        element={isUser ? <NewGroup /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/ExpensesAll"
        element={isUser ? <ExpensesAll /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/BalancesPage"
        element={isUser ? <BalancesPage /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/SettleUpPage"
        element={isUser ? <SettleUpPage /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/Settings"
        element={isUser ? <Settings /> : <Navigate to="/login" replace />}
      /> */}

      {/* User protected routes (with persistent sidebar) */}
      <Route
        path="/user"
        element={isUser ? <UserLayout /> : <Navigate to="/login" replace />}
      >
        <Route path="Userhome" element={<UserHome />} />
         Add more user pages later:
            {/* <Route path="my-balance" element={<MyBalance />} /> */}
            {/* <Route path="groups-joined" element={<NewGroup />} /> */}
            {/* <Route path="pending-settlements" element={<PendingSettlements />} />
            <Route path="expenses" element={<Expenses />} />
            <Route path="settings" element={<Settings />} />
         */}
      </Route>

      {/* Default */}
      {/* <Route path="/" element={<Navigate to="/login" replace />} /> */}

      {/* Catch-all */}
      {/* <Route path="*" element={<Navigate to="/login" replace />} /> */}
    </Routes>
  );
}