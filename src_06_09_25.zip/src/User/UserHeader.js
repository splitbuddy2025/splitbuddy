// src/User/UserHeader.js
import { Link, useNavigate } from "react-router-dom";

export default function UserHeader() {
  const navigate = useNavigate();

  // Get logged in user from sessionStorage
  const user = JSON.parse(sessionStorage.getItem("loggedInUser"));

  function handleLogout() {
    sessionStorage.removeItem("loggedInUser");
    navigate("/login");
  }

  return (
    <nav
      className="navbar navbar-expand-lg px-3"
      style={{
        background: "linear-gradient(90deg, #0077ff, #00c6ff)",
        boxShadow: "0 3px 8px rgba(0,0,0,0.15)",
        borderBottom: "3px solid #005bbb",
      }}
    >
      <Link
        className="navbar-brand fw-bold"
        to="/home"
        style={{
          color: "#fff",
          fontSize: "1.5rem",
          letterSpacing: "1px",
          transition: "transform 0.2s ease-in-out, color 0.2s",
        }}
        onMouseOver={(e) => (e.currentTarget.style.color = "#ffe082")}
        onMouseOut={(e) => (e.currentTarget.style.color = "#fff")}
      >
        💸 SplitBuddy
      </Link>

      {/* Mobile toggle */}
      <button
        className="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        style={{ border: "none" }}
      >
        <span className="navbar-toggler-icon"></span>
      </button>

      {/* Links */}
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav me-auto">
          {[
            { to: "/home", label: " Home" },
            { to: "/groups", label: " Groups" },
            { to: "/newgroup", label: " New Group" },
            //{ to: "/expenses", label: " Expenses" },
            { to: "/balances", label: " Balances" },
            //{ to: "/settle-up", label: " Settle Up" },
            { to: "/settings", label: " Settings" },
          ].map((item, idx) => (
            <li key={idx} className="nav-item">
              <Link
                className="nav-link"
                to={item.to}
                style={{
                  color: "#f5f5f5",
                  marginRight: "8px",
                  fontWeight: 500,
                  borderBottom: "2px solid transparent",
                  transition: "color 0.2s ease-in-out, border-bottom 0.2s",
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.color = "#ffe082";
                  e.currentTarget.style.borderBottom = "2px solid #ffe082";
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.color = "#f5f5f5";
                  e.currentTarget.style.borderBottom =
                    "2px solid transparent";
                }}
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>

        {/* Right side */}
        <div className="d-flex align-items-center">
          <span
            className="me-3"
            style={{ fontWeight: 600, color: "#fff" }}
          >
            {/* Show user name */}
            Welcome, {user?.name || "User"}
          </span>
          <button
            className="btn btn-sm me-2"
            style={{
              backgroundColor: "#fff",
              color: "#0077ff",
              borderRadius: "20px",
              fontWeight: 500,
              padding: "4px 12px",
            }}
          >
            Profile
          </button>
          <button
            className="btn btn-sm"
            style={{
              borderRadius: "20px",
              border: "1px solid #fff",
              color: "#fff",
              fontWeight: 500,
              padding: "4px 12px",
              transition: "all 0.2s ease",
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = "#fff";
              e.currentTarget.style.color = "#0077ff";
              e.currentTarget.style.borderColor = "#0077ff";
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = "transparent";
              e.currentTarget.style.color = "#fff";
              e.currentTarget.style.borderColor = "#fff";
            }}
            onClick={handleLogout}
          >
            🚪 Logout
          </button>
        </div>
      </div>
    </nav>
  );
}
