// src/User/SettleUpPage.js
import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import UserHeader from "./UserHeader";

export default function SettleUpPage() {
  const user = JSON.parse(sessionStorage.getItem("loggedInUser") || "null");

  const [balances, setBalances] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function loadBalances() {
      try {
        const res = await fetch(
          `http://localhost:4000/api/users/${user.user_id}/balance` // ✅ use user_id
        );
        const data = await res.json();
        setBalances(data);
      } catch (err) {
        console.error("Error fetching balances", err);
      }
    }
    if (user?.user_id) loadBalances();
  }, [user]);

  async function handleSettle(e) {
    e.preventDefault();
    setMessage("");

    if (!selectedUser || !amount) {
      setMessage("⚠️ Please select a user and enter an amount.");
      return;
    }

    try {
      const res = await fetch("http://localhost:4000/api/settlements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          from_user: user.user_id,
          to_user: selectedUser,
          amount: parseFloat(amount),
        }),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      setMessage("✅ Settlement successful!");
      setAmount("");
      setSelectedUser("");
    } catch (err) {
      console.error("Settlement error", err);
      setMessage("❌ Failed to settle, please try again.");
    }
  }

  return (
    <>
      <UserHeader />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          padding: "40px",
          background: "#f4f7fb",
          minHeight: "100vh",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "30px",
            boxShadow: "0 6px 18px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "600px",
          }}
        >
          <h2
            className="mb-4 text-center"
            style={{ color: "#0077ff", fontWeight: "bold" }}
          >
            💸 Settle Up
          </h2>

          <form onSubmit={handleSettle}>
            {/* Select user */}
            <div className="mb-3 text-start">
              <label className="form-label fw-semibold">Select User</label>
              <select
                className="form-select"
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                style={{ borderRadius: "8px", padding: "10px" }}
              >
                <option value="">-- Select --</option>
                {balances.map((bal, idx) => (
                  <option key={idx} value={bal.to_user}>
                    User #{bal.to_user}
                  </option>
                ))}
              </select>
            </div>

            {/* Amount */}
            <div className="mb-3 text-start">
              <label className="form-label fw-semibold">Amount</label>
              <input
                type="number"
                className="form-control"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                style={{ borderRadius: "8px", padding: "10px" }}
              />
            </div>

            {/* Submit */}
            <div className="d-grid">
              <button
                type="submit"
                className="btn btn-primary"
                style={{
                  borderRadius: "8px",
                  padding: "10px",
                  fontWeight: "600",
                }}
              >
                ✅ Settle
              </button>
            </div>
          </form>

          {/* Message */}
          {message && (
            <div
              className="alert mt-4"
              style={{
                borderRadius: "8px",
                backgroundColor: "#eaf4ff",
                color: "#004085",
                fontWeight: "500",
              }}
            >
              {message}
            </div>
          )}
        </div>
      </div>
      <Outlet />
    </>
  );
}
