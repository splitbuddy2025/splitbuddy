import React, { useEffect, useState } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";

// Admin components
import Overview from "./Overview";
import Activeusers from "./Activeusers";
import Usermanagement from "./Usermanagement";
import Contentmnagement from "./Contentmnagement";
import Groupmonitoring from "./Groupmonitoring";
import Queries from "./Queries";
import Exportdata from "./Exportdata";
import Login from "./Login";
import Registration from "./registration";

// User components
import UserLayout from "../User/Userlayout";
import UserHome from "../User/UserHome";

export default function AdminRoutes() {
  const [user, setUser] = useState(null);
  const location = useLocation();

  // Read session on every route change
  useEffect(() => {
    const loggedInUser = sessionStorage.getItem("loggedInUser");
    setUser(loggedInUser ? JSON.parse(loggedInUser) : null);
  }, [location]);

  const isAdmin = user?.role === "admin";
  const isUser = user?.role === "user";

  return (
    <Routes>
      {/* Public: Login */}
      <Route
        path="/login"
        element={
          user ? (
            isAdmin ? <Navigate to="/overview" replace /> : <Navigate to="/user/home" replace />
          ) : (
            <Login />
          )
        }
      />

      {/* Public: Register (only for non-logged-in, always creates a 'user') */}
      <Route
        path="/register"
        element={user ? <Navigate to="/login" replace /> : <Registration />}
      />

      {/* Admin protected routes */}
      <Route
        path="/overview"
        element={isAdmin ? <Overview /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/activeusers"
        element={isAdmin ? <Activeusers /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/usermanagement"
        element={isAdmin ? <Usermanagement /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/contentmnagement"
        element={isAdmin ? <Contentmnagement /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/groupmonitoring"
        element={isAdmin ? <Groupmonitoring /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/queries"
        element={isAdmin ? <Queries /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/exportdata"
        element={isAdmin ? <Exportdata /> : <Navigate to="/login" replace />}
      />

      {/* User protected routes (with persistent sidebar) */}
      <Route
        path="/user"
        element={isUser ? <UserLayout /> : <Navigate to="/login" replace />}
      >
        <Route path="home" element={<UserHome />} />
        {/* Add more user pages later:
            <Route path="my-balance" element={<MyBalance />} />
            <Route path="groups-joined" element={<GroupsJoined />} />
            <Route path="pending-settlements" element={<PendingSettlements />} />
            <Route path="expenses" element={<Expenses />} />
            <Route path="settings" element={<Settings />} />
        */}
      </Route>

      {/* Default */}
      <Route path="/" element={<Navigate to="/login" replace />} />

      {/* Catch-all */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
