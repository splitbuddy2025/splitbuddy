// Header.js
import React from "react";
import { FaBell, FaSearch } from "react-icons/fa";

export default function Header({ user }) {
  const handleLogout = () => {
    sessionStorage.removeItem("loggedInUser");
    window.location.href = "/login";
  };

  return (
    <header
      style={{
        background: "linear-gradient(90deg, #2a2c55, #8f94fb)",
        padding: "0.6rem 1.2rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
        position: "sticky",
        top: 0,
        zIndex: 1000,
      }}
    >
      {/* Left side - Brand */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
        <h2 style={{ color: "white", margin: 0, fontWeight: "600" }}>
          Admin Dashboard
        </h2>
      </div>

      {/* Middle - Search */}
      <div
        style={{
          background: "white",
          display: "flex",
          alignItems: "center",
          borderRadius: "20px",
          padding: "0.3rem 0.8rem",
          width: "250px",
        }}
      >
        <FaSearch style={{ color: "#aaa", marginRight: "0.5rem" }} />
        <input
          type="text"
          placeholder="Search..."
          style={{
            border: "none",
            outline: "none",
            width: "100%",
            fontSize: "0.9rem",
          }}
        />
      </div>

      {/* Right side - Notifications + Profile + Logout */}
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        {/* Notifications */}
        <button
          style={{
            background: "transparent",
            border: "none",
            position: "relative",
            cursor: "pointer",
          }}
        >
          <FaBell style={{ color: "white", fontSize: "1.2rem" }} />
          <span
            style={{
              position: "absolute",
              top: "-5px",
              right: "-5px",
              background: "red",
              color: "white",
              fontSize: "0.7rem",
              padding: "2px 6px",
              borderRadius: "50%",
            }}
          >
            5
          </span>
        </button>

        {/* Profile + Logout */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.6rem",
            background: "rgba(255,255,255,0.15)",
            padding: "0.3rem 0.6rem",
            borderRadius: "20px",
          }}
        >
          <img
            src={user?.profileImage || "https://via.placeholder.com/40"}
            alt="Profile"
            style={{
              width: "32px",
              height: "32px",
              borderRadius: "50%",
              objectFit: "cover",
              border: "2px solid white",
            }}
          />
          <span style={{ color: "white", fontWeight: "500" }}>
            {user?.name || "Admin"}
          </span>
          <button
            onClick={handleLogout}
            style={{
              background: "transparent",
              border: "1px solid white",
              color: "white",
              padding: "2px 8px",
              borderRadius: "12px",
              cursor: "pointer",
              fontSize: "0.8rem",
            }}
          >
            Logout
          </button>
        </div>
      </div>
    </header>
  );
}
