import { Outlet } from "react-router-dom";
import UserSidebar from "./UserSidebar";

export default function UserLayout() {
  return (
    <div style={{ display: "flex", height: "100vh" }}>
      {/* Sidebar stays visible */}
      <UserSidebar />
      {/* Page content */}
      <div style={{ flex: 1, padding: "20px", overflowY: "auto" }}>
        <Outlet />
      </div>
    </div>
  );
}
