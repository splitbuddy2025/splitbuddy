import { useNavigate } from "react-router-dom";

export default function UserHome() {
  const navigate = useNavigate();

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Welcome to SplitBuddy</h2>
        {/* Logout button removed (only in sidebar) */}
      </div>

      <p>This is your dashboard.</p>

      <div className="row mt-4">
        {/* My Balance */}
        <div className="col-md-4">
          <div
            className="card p-3 shadow-sm"
            style={{ cursor: "pointer" }}
            onClick={() => navigate("/user/my-balance")}
          >
            <h5>My Balance</h5>
            <p>₹0</p>
          </div>
        </div>

        {/* Groups Joined */}
        <div className="col-md-4">
          <div
            className="card p-3 shadow-sm"
            style={{ cursor: "pointer" }}
            onClick={() => navigate("/user/groups-joined")}
          >
            <h5>Groups Joined</h5>
            <p>0</p>
          </div>
        </div>

        {/* Pending Settlements */}
        <div className="col-md-4">
          <div
            className="card p-3 shadow-sm"
            style={{ cursor: "pointer" }}
            onClick={() => navigate("/user/pending-settlements")}
          >
            <h5>Pending Settlements</h5>
            <p>0</p>
          </div>
        </div>
      </div>
    </div>
  );
}
