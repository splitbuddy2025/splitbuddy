import { NavLink, useNavigate } from "react-router-dom";

export default function UserSidebar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    sessionStorage.removeItem("loggedInUser");
    navigate("/login", { replace: true }); // prevents back to protected pages
  };

  const linkClass = ({ isActive }) =>
    `nav-link ${isActive ? "fw-bold text-warning" : "text-white"}`;

  return (
    <div
      style={{
        width: "220px",
        background: "#222",
        color: "white",
        padding: "20px",
        minHeight: "100vh",
      }}
    >
      <h3 className="mb-4">SplitBuddy</h3>
      <nav className="nav flex-column">
        <NavLink to="/user/home" className={linkClass}>
          Home
        </NavLink>
        <NavLink to="/user/my-balance" className={linkClass}>
          My Balance
        </NavLink>
        <NavLink to="/user/groups-joined" className={linkClass}>
          Groups Joined
        </NavLink>
        <NavLink to="/user/pending-settlements" className={linkClass}>
          Pending Settlements
        </NavLink>
        <NavLink to="/user/expenses" className={linkClass}>
          Expenses
        </NavLink>
        <NavLink to="/user/settings" className={linkClass}>
          Settings
        </NavLink>
      </nav>

      <button className="btn btn-danger w-100 mt-4" onClick={handleLogout}>
        Logout
      </button>
    </div>
  );
}
